"""
PyInstaller Build Script to Generate MA_Copilot_AI.exe
Run this script to compile the application into a single executable file.
"""
import subprocess
import sys

def build_executable():
    print("Installing PyInstaller if needed...")
    subprocess.run([sys.executable, "-m", "pip", "install", "pyinstaller"], check=False)
    
    print("Building Standalone MA_Copilot_AI.exe Executable...")
    cmd = [
        "pyinstaller",
        "--noconfirm",
        "--onedir",
        "--name=MA_Copilot_AI",
        "--console",
        "launch_desktop_app.py"
    ]
    res = subprocess.run(cmd)
    if res.returncode == 0:
        print("\nSUCCESS! Executable built in dist/MA_Copilot_AI/MA_Copilot_AI.exe")
    else:
        print("\nBuild completed or requires additional modules.")

if __name__ == "__main__":
    build_executable()
