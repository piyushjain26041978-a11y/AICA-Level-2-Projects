# M&A COPILOT AI — SYSTEM & AI ARCHITECTURE

## 1. Executive Summary
The M&A Copilot is a hybrid AI decision-support platform designed for Chartered Accountants, valuation experts, and financial due diligence teams. It ingests transaction data rooms containing heterogeneous financial statements, tax returns, journal entries, legal contracts, and customer schedules, converting them into structured evidence-backed deal intelligence.

---

## 2. RAG & Vector Retrieval Pipeline

```
[ Data Room Documents (PDF, DOCX, XLSX, CSV, TXT) ]
                       │
                       ▼
         [ Data Room Ingestion Engine ]
    - Document Parser (PyMuPDF, docx, openpyxl)
    - Metadata Extraction (Filename, Page #, Sheet Name)
    - Text Cleaning & Chunking (~1000 chars per chunk)
                       │
                       ▼
       ┌───────────────┴───────────────┐
       ▼                               ▼
 [ Offline Mode: TF-IDF ]     [ Online Mode: OpenAI Embeddings ]
 - Scikit-Learn Vectorizer    - Text-Embedding-3-Small / Large
 - Cosine Similarity Matrix   - Vector Store Index
       └───────────────┬───────────────┘
                       │
                       ▼
          [ Relevance Retrieval Engine ]
    - Retrieves Top-K (K=4) Most Relevant Evidence Chunks
    - Filters by Similarity Threshold Score (>0.05)
                       │
                       ▼
         [ Anti-Hallucination Guardrail ]
    - Prompt Constraint: "Use strictly supplied context."
    - Fallback: "Insufficient evidence available in Data Room."
                       │
                       ▼
      [ LLM Synthesis & Citation Formatting ]
    - Returns structured answer with explicit tags:
      [Source: filename.pdf | Page 17]
```

---

## 3. Multi-Agent Specialist Framework

```
                       [ M&A Lead Agent ]
    (Consolidation, Risk Ranking, Contradiction Removal, Synthesis)
                               │
   ┌──────┬──────┬──────┬──────┼──────┬──────┬──────┬──────┐
   ▼      ▼      ▼      ▼      ▼      ▼      ▼      ▼      ▼
 Financial QoE   Tax    GST Commercial RP Forensic Legal Valuation
 Agent   Agent  Agent  Agent  Agent  Agent  Agent  Agent   Agent
```

Each specialist agent operates independently on context data to produce:
1. Primary Finding
2. Source Evidence
3. Risk Score & Level (0-100)
4. Deal Impact (EV / Equity Value effect)
5. Recommended Management Action

---

## 4. Human-in-the-Loop Governance
Professional judgment remains strictly with the Chartered Accountant.
All AI recommendations are tagged as:
- `"Potential adjustment — subject to validation"`
- `"Indicative exposure — professional validation required"`

Reviewers interact via an interactive audit trail to **Accept**, **Reject**, **Request Evidence**, **Ask Management**, or **Escalate** findings prior to final report generation.
