"""
Multi-Method Valuation Engine
Computes Enterprise Value and Equity Value using Income (DCF), Market (Trading & Transaction Multiples),
and Asset (Adjusted NAV) approaches. Provides a Weighted Average Valuation Matrix.
Follows CA Guardrail: "Illustrative Valuation Summary — Not a formal valuation opinion under Sec 247 of Companies Act 2013."
"""
import pandas as pd
import numpy as np

def run_dcf_valuation(
    base_fcf=12.5,          # FY25 Base Free Cash Flow (INR Cr)
    wacc_pct=12.5,          # Weighted Average Cost of Capital (%)
    terminal_growth=3.0,    # Perpetual Terminal Growth Rate (%)
    projection_years=5,     # Forecast Horizon (Years)
    fcf_growth_pct=8.0      # Projected FCF Growth Rate (%)
):
    """
    Discounted Cash Flow (DCF) FCFF Model.
    """
    fcf_projections = []
    current_fcf = base_fcf
    
    discount_factors = []
    pv_fcfs = []
    
    for yr in range(1, projection_years + 1):
        current_fcf = current_fcf * (1 + fcf_growth_pct / 100.0)
        disc_factor = 1 / ((1 + wacc_pct / 100.0) ** yr)
        pv = current_fcf * disc_factor
        
        fcf_projections.append(round(current_fcf, 2))
        discount_factors.append(round(disc_factor, 4))
        pv_fcfs.append(round(pv, 2))
        
    sum_pv_fcf = sum(pv_fcfs)
    
    # Terminal Value (Gordon Growth)
    last_fcf = fcf_projections[-1]
    terminal_fcf = last_fcf * (1 + terminal_growth / 100.0)
    terminal_value = terminal_fcf / ((wacc_pct - terminal_growth) / 100.0)
    pv_terminal_value = terminal_value * (1 / ((1 + wacc_pct / 100.0) ** projection_years))
    
    dcf_enterprise_value = sum_pv_fcf + pv_terminal_value
    
    dcf_schedule = pd.DataFrame({
        "Projection Year": [f"Year {i}" for i in range(1, projection_years + 1)],
        "Projected FCFF (Cr)": fcf_projections,
        "Discount Factor": discount_factors,
        "Present Value (Cr)": pv_fcfs
    })
    
    dcf_summary = {
        "Base FCF": base_fcf,
        "WACC (%)": wacc_pct,
        "Terminal Growth (%)": terminal_growth,
        "Sum PV 5-Yr FCF (Cr)": round(sum_pv_fcf, 2),
        "Terminal Value (Cr)": round(terminal_value, 2),
        "PV Terminal Value (Cr)": round(pv_terminal_value, 2),
        "DCF Enterprise Value (Cr)": round(dcf_enterprise_value, 2)
    }
    
    return dcf_schedule, dcf_summary

def run_multi_method_valuation_summary(
    base_ev=250.0,
    adj_ebitda=16.95,
    rep_ebitda=26.00,
    rev_fy25=148.0,
    gross_debt=36.5,
    cash=4.5,
    wc_adj=10.8,
    tax_exp=8.07,
    debt_like=4.65,
    ev_ebitda_mult=9.6,
    ev_rev_mult=1.5,
    pe_mult=14.0,
    wacc_pct=12.5,
    **kwargs
):
    """
    Computes Valuation across 4 primary methodologies and builds a Weighted Average Valuation Matrix.
    """
    net_deductions = (gross_debt - cash) + wc_adj + tax_exp + debt_like  # 55.52 Cr
    
    # 1. DCF Method
    _, dcf_sum = run_dcf_valuation(base_fcf=12.5, wacc_pct=wacc_pct)
    ev_dcf = dcf_sum["DCF Enterprise Value (Cr)"]
    eq_dcf = ev_dcf - net_deductions
    
    # 2. Market Approach - EV/EBITDA Multiple (Adjusted EBITDA)
    ev_ebitda = adj_ebitda * ev_ebitda_mult
    eq_ebitda = ev_ebitda - net_deductions
    
    # 3. Market Approach - EV/Revenue Multiple
    ev_rev = rev_fy25 * ev_rev_mult
    eq_rev = ev_rev - net_deductions
    
    # 4. Asset Approach - Net Asset Value (NAV / Book Value Adjusted)
    total_assets = 128.3
    total_liabilities = 36.5 + 24.1 + 9.4  # 70.0
    book_nav = total_assets - total_liabilities  # 58.3 Cr
    adj_nav = book_nav - 12.0  # Fair value adjustment for obsolete stock & uncollectible debtors
    ev_nav = adj_nav + net_deductions
    eq_nav = adj_nav
    
    methods = [
        {
            "Valuation Approach": "Income Approach",
            "Methodology": "Discounted Cash Flow (DCF FCFF)",
            "Key Parameter / Multiple": f"WACC: {wacc_pct}%, g: 3.0%",
            "Enterprise Value (INR Cr)": round(ev_dcf, 2),
            "Indicative Equity Value (INR Cr)": round(eq_dcf, 2),
            "Assigned Weight (%)": 40.0
        },
        {
            "Valuation Approach": "Market Approach",
            "Methodology": "EV / Adjusted EBITDA Multiple",
            "Key Parameter / Multiple": f"{ev_ebitda_mult:.1f}x Adjusted EBITDA",
            "Enterprise Value (INR Cr)": round(ev_ebitda, 2),
            "Indicative Equity Value (INR Cr)": round(eq_ebitda, 2),
            "Assigned Weight (%)": 40.0
        },
        {
            "Valuation Approach": "Market Approach",
            "Methodology": "EV / Revenue Multiple",
            "Key Parameter / Multiple": f"{ev_rev_mult:.2f}x FY25 Revenue",
            "Enterprise Value (INR Cr)": round(ev_rev, 2),
            "Indicative Equity Value (INR Cr)": round(eq_rev, 2),
            "Assigned Weight (%)": 10.0
        },
        {
            "Valuation Approach": "Asset Approach",
            "Methodology": "Adjusted Net Asset Value (NAV)",
            "Key Parameter / Multiple": "Fair Value Adjusted NAV",
            "Enterprise Value (INR Cr)": round(ev_nav, 2),
            "Indicative Equity Value (INR Cr)": round(eq_nav, 2),
            "Assigned Weight (%)": 10.0
        }
    ]
    
    val_df = pd.DataFrame(methods)
    
    # Calculate Weighted Average Valuation
    weighted_ev = sum((row["Assigned Weight (%)"] / 100.0) * row["Enterprise Value (INR Cr)"] for row in methods)
    weighted_eq = sum((row["Assigned Weight (%)"] / 100.0) * row["Indicative Equity Value (INR Cr)"] for row in methods)
    
    total_shares = 1.0  # 1.0 Crore shares
    per_share_value = (weighted_eq * 1e7) / (total_shares * 1e7)
    
    summary = {
        "Weighted Average Enterprise Value": round(weighted_ev, 2),
        "Weighted Average Equity Value": round(weighted_eq, 2),
        "Total Share Count": f"{total_shares:.2f} Crore Shares",
        "Indicative Fair Value per Share": f"INR {per_share_value:.2f} / share"
    }
    
    return val_df, summary
