"""
AI Copilot Module
Exposes RAGEngine for transaction Q&A and conversational due-diligence assistance.
"""
from modules.rag_engine import RAGEngine

__all__ = ["RAGEngine"]
