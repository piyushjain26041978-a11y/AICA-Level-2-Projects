"""
AI Management Question Generator Engine
Converts analytical findings into professional, non-accusatory, evidence-based management due diligence questions.
Categorized into 12 DD functional areas.
"""
import pandas as pd

def generate_management_questions():
    """
    Returns a comprehensive list of categorized management due diligence questions with findings and sources.
    """
    questions = [
        {
            "Category": "Financial & Cash Flow",
            "Finding": "Receivables increased by 44.1% YoY (INR 28.6 Cr to INR 41.2 Cr) while revenue grew by only 7.1%. CFO conversion dropped from 73% to 30%.",
            "Management Question": "Please explain the commercial reasons for the significant increase in receivables relative to revenue. Kindly provide customer-wise invoice ageing, subsequent collection report post 31 March 2025, and details of extended credit terms granted to major accounts.",
            "Target Recipient": "CFO / Finance Controller",
            "Priority": "URGENT",
            "Evidence Source": "[Source: Financials.xlsx | Sheet P&L & BalanceSheet]"
        },
        {
            "Category": "Quality of Earnings (QoE)",
            "Finding": "INR 3.80 Cr paid as Management Consultancy Fees to KMP Consulting Services (promoter-owned entity) without formal contract or verifiable deliverables.",
            "Management Question": "Please provide copies of the executed service agreement, board approvals, scope of work, monthly timesheets, and third-party arm's length benchmarking study for the advisory fees paid to KMP Consulting Services.",
            "Target Recipient": "Managing Director / Legal Counsel",
            "Priority": "URGENT",
            "Evidence Source": "[Source: Journal_Entries.xlsx | JV-2025-902 & Related_Party_Master.xlsx]"
        },
        {
            "Category": "GST Due Diligence",
            "Finding": "GSTR-3B reported turnover is lower by INR 6.80 Cr compared to Books of Accounts, resulting in an estimated undischarged GST liability of INR 1.22 Cr. Ineligible ITC of INR 2.05 Cr claimed in 3B not matching GSTR-2A.",
            "Management Question": "Please provide a period-wise reconciliation statement between Books of Accounts, GSTR-1, GSTR-3B, and GSTR-2A for FY 2024-25, along with reasons for turnover differences and unmatched ITC claims.",
            "Target Recipient": "Head of Taxation / GST Manager",
            "Priority": "URGENT",
            "Evidence Source": "[Source: GST_Books.xlsx vs GST_Return.xlsx]"
        },
        {
            "Category": "Tax Due Diligence",
            "Finding": "Contingent exposure of INR 4.80 Cr pending before ITAT regarding Sec 80IA exemption disallowance & Transfer Pricing royalty addition.",
            "Management Question": "Please provide the latest status of the appeal pending before ITAT, copies of written submissions filed by legal counsel, and the independent tax opinion evaluating the probability of adverse outcome.",
            "Target Recipient": "Head of Taxation",
            "Priority": "HIGH",
            "Evidence Source": "[Source: Tax_Data.xlsx | AY 2021-22]"
        },
        {
            "Category": "Commercial Concentration",
            "Finding": "Apex Global Corp accounts for 37.0% of FY25 revenue (INR 54.76 Cr) and customer sales contract expires on 31 December 2025.",
            "Management Question": "What is the current status of contract renewal negotiations with Apex Global Corp? Have any revised credit terms, price discounts, or volume commitments been requested by the customer?",
            "Target Recipient": "Chief Commercial Officer / MD",
            "Priority": "URGENT",
            "Evidence Source": "[Source: Customer_Sales.xlsx & Demo_Legal_Memo.txt]"
        },
        {
            "Category": "Related Party Transactions",
            "Finding": "Factory land at Unit-1 is leased from spouse of MD at INR 1.20 Cr/yr, estimated to be 30% above prevailing commercial lease rates.",
            "Management Question": "Please provide the original registered lease agreement for Unit-1, independent property valuation certificate supporting the lease rent, and details of any proposed lease renewal terms.",
            "Target Recipient": "Company Secretary / MD",
            "Priority": "HIGH",
            "Evidence Source": "[Source: Demo_Legal_Memo.txt | Section 3]"
        },
        {
            "Category": "Forensic Analytics",
            "Finding": "Manual year-end journal entry JV-2025-901 posted by SUPERADMIN on 31 March 2025 crediting Revenue by INR 55.0 Lakhs under Unbilled Revenue.",
            "Management Question": "Please provide supporting documentation, customer milestone acceptance certificates, and subsequent billing details for the manual unbilled revenue journal entry JV-2025-901.",
            "Target Recipient": "Chief Accountant / Auditor",
            "Priority": "HIGH",
            "Evidence Source": "[Source: Journal_Entries.xlsx | JV-2025-901]"
        },
        {
            "Category": "Working Capital & Inventory",
            "Finding": "Inventory days (DIO) increased from 85 to 110 days with INR 3.80 Cr in raw material resin stock remaining unutilized for > 180 days.",
            "Management Question": "Please provide physical inventory count sheets as on 31 March 2025, ageing analysis of raw materials and finished goods, and policy for provision against slow-moving/obsolete inventory.",
            "Target Recipient": "Head of Supply Chain / Plant Manager",
            "Priority": "HIGH",
            "Evidence Source": "[Source: BalanceSheet & Debtor_Ageing.xlsx]"
        },
        {
            "Category": "HR & Legal",
            "Finding": "Gratuity liability of INR 1.85 Cr is unfunded and non-compete agreements are missing for 2 Senior Vice Presidents in R&D.",
            "Management Question": "Please confirm if an actuarial valuation report under AS-15 / IND AS 19 has been obtained for gratuity liabilities, and provide copies of employment contracts and non-compete agreements for key R&D personnel.",
            "Target Recipient": "Head of HR / Legal Head",
            "Priority": "MODERATE",
            "Evidence Source": "[Source: Demo_Legal_Memo.txt | Section 4]"
        }
    ]
    
    return pd.DataFrame(questions)
