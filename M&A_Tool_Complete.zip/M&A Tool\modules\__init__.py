"""
M&A Copilot Core Modules Package
"""
