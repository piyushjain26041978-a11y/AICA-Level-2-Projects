"""
Deal Scenario Lab
Simulates deal value impact under Base Case, Downside Case, and Severe Downside Case scenarios.
"""
import pandas as pd

def run_scenario_simulation(
    base_rev=148.0,
    base_ebitda=26.0,
    base_ev=250.0,
    base_net_debt=32.0,
    rev_downside_pct=0.0,
    margin_pressure_bps=0.0,
    add_debt=0.0,
    wc_adj_input=10.8,
    tax_exp_input=8.07,
    customer_loss_pct=0.0
):
    """
    Computes financial parameters and Equity Value across 3 cases.
    """
    # 1. Base Case
    rev_base = base_rev
    ebitda_base = base_ebitda
    ev_base = base_ev
    eq_val_base = ev_base - base_net_debt - wc_adj_input - tax_exp_input
    
    # 2. User Selected Custom / Downside Case
    total_rev_drop = (rev_downside_pct + customer_loss_pct) / 100.0
    rev_downside = base_rev * (1.0 - total_rev_drop)
    
    margin_base_pct = (base_ebitda / base_rev)
    margin_downside_pct = max(0.05, margin_base_pct - (margin_pressure_bps / 10000.0))
    ebitda_downside = rev_downside * margin_downside_pct
    
    # EV adjusted by EBITDA change multiple (~9.6x multiple)
    ebitda_multiple = base_ev / base_ebitda
    ev_downside = ebitda_downside * ebitda_multiple
    net_debt_downside = base_net_debt + add_debt
    
    eq_val_downside = ev_downside - net_debt_downside - wc_adj_input - tax_exp_input
    
    # 3. Severe Downside Case (Stress Test: 20% Sales Drop, 400 bps Margin Compression, +15 Cr Debt)
    rev_severe = base_rev * 0.80
    ebitda_severe = rev_severe * (margin_base_pct - 0.04)
    ev_severe = ebitda_severe * ebitda_multiple
    net_debt_severe = base_net_debt + 15.0
    eq_val_severe = ev_severe - net_debt_severe - (wc_adj_input * 1.2) - (tax_exp_input * 1.2)
    
    scenario_table = [
        {
            "Scenario": "Base Case",
            "Revenue (INR Cr)": round(rev_base, 2),
            "EBITDA (INR Cr)": round(ebitda_base, 2),
            "EBITDA Margin (%)": f"{((ebitda_base/rev_base)*100):.1f}%",
            "Enterprise Value (INR Cr)": round(ev_base, 2),
            "Net Debt (INR Cr)": round(base_net_debt, 2),
            "Indicative Equity Value (INR Cr)": round(eq_val_base, 2),
            "Equity Value Change (%)": "0.0% (Base)",
            "Key Driver": "Management P&L Baseline"
        },
        {
            "Scenario": "Custom Downside Case",
            "Revenue (INR Cr)": round(rev_downside, 2),
            "EBITDA (INR Cr)": round(ebitda_downside, 2),
            "EBITDA Margin (%)": f"{((ebitda_downside/rev_downside)*100):.1f}%",
            "Enterprise Value (INR Cr)": round(ev_downside, 2),
            "Net Debt (INR Cr)": round(net_debt_downside, 2),
            "Indicative Equity Value (INR Cr)": round(eq_val_downside, 2),
            "Equity Value Change (%)": f"{(((eq_val_downside - eq_val_base)/eq_val_base)*100):.1f}%",
            "Key Driver": f"Sales Drop ({rev_downside_pct:.0f}%), Margin Pressure ({margin_pressure_bps:.0f} bps)"
        },
        {
            "Scenario": "Severe Stress Case",
            "Revenue (INR Cr)": round(rev_severe, 2),
            "EBITDA (INR Cr)": round(ebitda_severe, 2),
            "EBITDA Margin (%)": f"{((ebitda_severe/rev_severe)*100):.1f}%",
            "Enterprise Value (INR Cr)": round(ev_severe, 2),
            "Net Debt (INR Cr)": round(net_debt_severe, 2),
            "Indicative Equity Value (INR Cr)": round(eq_val_severe, 2),
            "Equity Value Change (%)": f"{(((eq_val_severe - eq_val_base)/eq_val_base)*100):.1f}%",
            "Key Driver": "20% Sales Drop, 400 bps Margin Compression, +15 Cr Debt"
        }
    ]
    
    return pd.DataFrame(scenario_table)
