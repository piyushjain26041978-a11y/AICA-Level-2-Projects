# PROFESSIONAL & LEGAL DISCLAIMER

**M&A Copilot — AI-Powered Due Diligence, Risk Identification & Deal Intelligence Platform**

### 1. Decision-Support System Disclosure
M&A Copilot AI is designed strictly as an **AI-assisted professional decision-support tool** for Chartered Accountants, financial analysts, tax advisors, and M&A transaction teams. 

**IT IS NOT A REPLACEMENT FOR:**
- A statutory or forensic audit conducted under Auditing Standards (SA).
- A formal tax opinion issued by a qualified Tax Advocate or Chartered Accountant.
- A legal due diligence report or legal opinion issued by an Advocate.
- A valuation report issued by a Registered Valuer under Section 247 of the Companies Act, 2013 or IBBI guidelines.

### 2. Indicative Nature of Findings
All AI-generated outputs, Quality of Earnings (QoE) adjustments, working capital adjustments, tax exposure calculations, and 0–100 deal risk scores are **indicative estimates**. They are subject to mandatory independent verification against original source documents, books of account, and statutory filings.

### 3. Professional Guardrails
- **Quality of Earnings**: Items flagged for EBITDA adjustments use the explicit designation *"Potential adjustment — subject to validation"*. No item is automatically classified as a definitive add-back or deduction without human review.
- **Tax & GST Exposure**: Indirect tax mismatches and contingent liability assessments use the designation *"Indicative exposure — professional validation required"*.
- **Related Party Matching**: Entity matching results are designated as *"Potential related-party indicator"*.
- **Forensic Journal Anomalies**: Anomaly entries are flagged as *"Potential anomaly requiring investigation"*, not as definitive findings of fraud.

### 4. Source Citation Guarantee
Every factual claim presented by the RAG Engine references the specific source document and location in the format `[Source: filename | Page/Sheet]`. If evidence in the Data Room is insufficient, the system explicitly reports *"Insufficient evidence available in the Data Room."*

### 5. Compliance with ICAI Ethical Guidelines
This platform enforces the fundamental principles of professional competence, due care, and professional skepticism as mandated by the Institute of Chartered Accountants of India (ICAI). The ultimate responsibility for all due diligence opinions and deal reports rests solely with the practicing Chartered Accountant.
