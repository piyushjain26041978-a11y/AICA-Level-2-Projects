# M&A Copilot — AI-Powered Due Diligence, Risk Identification & Deal Intelligence Platform

> **Tagline**: From Data Room to Deal Intelligence  
> **Target Audience**: Chartered Accountants, M&A Advisory Teams, Financial Analysts, Auditors  
> **ICAI AICA Level-2 Capstone Demonstration**

---

## 🌟 Executive Overview
**M&A Copilot AI** is a complete, production-grade, offline-capable AI decision-support platform that ingests transaction data rooms (PDFs, Word docs, Excel models, CSVs, TXT legal memos) and converts heterogeneous unstructured data into structured deal intelligence.

### Key Capabilities
- 📁 **Data Room Ingestion**: Automatic parsing and text chunking with metadata preservation (`[Source: filename | Page X / Sheet Y]`).
- 🤖 **Hybrid RAG Engine**: Works 100% offline using TF-IDF + Cosine Similarity, or online via OpenAI API. Strict anti-hallucination guardrails.
- 📈 **Financial Analysis Engine**: Ratio analytics, DSO/DIO/DPO, CFO/EBITDA conversion, trend flags.
- ⚖️ **Quality of Earnings (QoE)**: Reported EBITDA → Potential Adjustments → Normalised Adjusted EBITDA bridge.
- 🔄 **Working Capital Peg Analysis**: $WC_{actual} - WC_{peg}$ calculation with overdue ageing red flags.
- 🏛️ **GST & Tax DD**: GSTR-3B vs Books turnover & ITC mismatch detection; Income Tax contingent liabilities summary.
- 🏢 **Commercial Analysis**: Top 1/3/5 customer concentration ratios, Herfindahl-Hirschman Index (HHI), supplier dependency.
- 🤝 **Related Party DD**: Director/KMP relationship matching, arm's length evaluation register.
- 🔍 **Forensic Analytics**: Flagged anomaly journal population (round sums, weekend entries, post-closing manual JVs).
- 🎯 **Deal Value Bridge**: Enterprise Value to Equity Value Bridge ($EV - Debt + Cash \pm WC_{adj} - Tax_{exp} - Debt_{like} = Equity Value$).
- 🧪 **Dynamic Scenario Simulator**: Stress testing Equity Value under Base, Downside, and Severe Downside cases.
- ⚠️ **Explainable Risk Centre**: 0–100 risk score across 15 DD categories with Low / Moderate / High / Critical classification.
- 💬 **Conversational AI Copilot**: RAG Q&A with mandatory source citations.
- ❓ **Management Question Generator**: Evidence-based DD questions across 12 functional categories.
- 🤖 **Multi-Agent Review Panel**: 9 Specialist AI Agents + 1 Lead M&A Agent synthesis.
- 📋 **Human-in-the-Loop Governance**: Interactive CA review audit trail (Accept / Reject / Escalate).
- 📄 **Report Generation**: PDF (ReportLab), 14-sheet Excel workbook (OpenPyXL), and formatted TXT exporter.

---

## 🚀 Quick Start Guide

### Prerequisites
- Python 3.10 or higher installed.

### Option 1: 1-Click Launch (Windows)
Double-click `run_app.bat` to automatically install dependencies and launch the Streamlit application.

### Option 2: Manual Shell Execution
```bash
# 1. Install dependencies
pip install -r requirements.txt

# 2. Generate sample data (Optional - pre-built data included)
python create_sample_data.py

# 3. Launch Streamlit Application
streamlit run app.py
```

Streamlit will launch automatically in your web browser at `http://localhost:8501`.

---

## 📁 Directory Structure
```
M&A Tool/
├── app.py                         # Main Streamlit Application (15 Interactive Tabs)
├── config.py                      # Configurations, Theme Styling, Metadata
├── requirements.txt               # Dependencies
├── run_app.bat                    # 1-Click Launcher
├── create_sample_data.py          # Sample Data Generator Script
├── 00_Master_Development_Prompt.txt
├── README.md                      # Complete Setup & Operational Guide
├── modules/                       # Core Analytical & AI Engines
│   ├── __init__.py
│   ├── data_room.py               # Document Loader (PDF, DOCX, XLSX, CSV, TXT)
│   ├── rag_engine.py              # Hybrid RAG Engine (TF-IDF Offline + OpenAI Online)
│   ├── financial_engine.py        # Financial Ratios & Cash Flow Analytics
│   ├── qoe_engine.py              # Quality of Earnings & EBITDA Normalization
│   ├── working_capital_engine.py  # Ageing & NWC Peg Analysis Engine
│   ├── tax_gst_engine.py          # GST 2A/3B Reconciliation & Tax Contingent Exposure
│   ├── related_party_engine.py    # Related Party Entity Matching & Arm's Length Audit
│   ├── forensic_engine.py         # Forensic Journal Entry Exception Analytics
│   ├── commercial_engine.py       # Concentration Ratios (HHI Index) & Supplier Risk
│   ├── deal_value_engine.py       # Enterprise Value to Equity Value Bridge
│   ├── scenario_lab.py            # Dynamic Sensitivity Simulator (Base / Downside / Severe)
│   ├── risk_scoring.py            # Explainable 0-100 Risk Centre Engine
│   ├── ai_copilot.py              # RAG Assistant Module
│   ├── management_questions.py    # Evidence-Based Management Question Generator
│   ├── multi_agent.py             # 9 Specialist AI Agents + Lead M&A Agent Synthesis
│   ├── human_in_loop.py           # CA Reviewer Audit Trail Module
│   └── report_generator.py        # PDF, Excel (14 sheets), and TXT Report Exporters
├── sample_data/                   # Pre-populated Realistic Demonstration Data
│   ├── financials.xlsx
│   ├── customer_sales.xlsx
│   ├── debtor_ageing.xlsx
│   ├── creditor_ageing.xlsx
│   ├── vendor_data.xlsx
│   ├── gst_books.xlsx
│   ├── gst_return.xlsx
│   ├── tax_data.xlsx
│   ├── related_party_master.xlsx
│   ├── journal_entries.xlsx
│   └── Demo_Legal_Memo.txt
└── docs/                          # ICAI AICA Level-2 Documentation & Deliverables
    ├── 01_AI_Architecture.md
    ├── 02_Project_Synopsis.md
    ├── 03_ICAI_Presentation.md
    ├── 04_Demo_Script.md
    ├── 05_Viva_Questions.md
    ├── 06_User_Manual.md
    └── 07_Professional_Disclaimer.md
```

---

## ⚖️ Professional & Ethical Guardrails
- **Decision Support**: The application is explicitly designed as a professional decision-support system and **NOT** as a replacement for a Chartered Accountant, auditor, tax advisor, or valuation professional.
- **Source Attribution**: Every factual output cites its exact data room source `[Source: filename | Page X / Sheet Y]`.
- **Anti-Hallucination**: Answers strictly from evidence or explicitly states *"Insufficient evidence available in the Data Room."*
- **Qualified Language**: Uses non-definitive wording: *"Potential adjustment — subject to validation"* and *"Indicative exposure — professional validation required"*.
