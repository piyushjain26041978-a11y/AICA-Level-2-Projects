"""
Forensic Journal Analytics Engine
Analyzes journal entry populations to detect manual entries, round numbers, year-end post-closing adjustments,
privileged user postings, and Benford's Law first-digit anomalies.
Follows CA guardrail: "Potential anomaly requiring investigation — not a definitive audit finding."
"""
import math
import pandas as pd
import numpy as np

def calculate_benfords_law_distribution(je_df=None):
    """
    Computes first-digit frequency distribution of journal entry amounts vs Benford's Law expected probability.
    Benford's Law: P(d) = log10(1 + 1/d)
    """
    if je_df is None or "Amount (INR)" not in je_df.columns:
        return pd.DataFrame()
    
    amounts = je_df["Amount (INR)"].dropna()
    first_digits = []
    
    for amt in amounts:
        val_str = str(abs(amt)).replace(".", "").lstrip("0")
        if val_str and val_str[0].isdigit() and val_str[0] != "0":
            first_digits.append(int(val_str[0]))
            
    if not first_digits:
        return pd.DataFrame()
        
    total_count = len(first_digits)
    digit_counts = pd.Series(first_digits).value_counts().to_dict()
    
    benford_data = []
    for d in range(1, 10):
        actual_cnt = digit_counts.get(d, 0)
        actual_pct = round((actual_cnt / total_count) * 100, 1)
        expected_pct = round(math.log10(1 + 1 / d) * 100, 1)
        diff = round(actual_pct - expected_pct, 1)
        anomaly_flag = "⚠️ ANOMALY (Spike)" if diff > 5.0 else ("⚠️ ANOMALY (Deficit)" if diff < -5.0 else "Normal")
        
        benford_data.append({
            "First Digit": d,
            "Actual Count": actual_cnt,
            "Actual Frequency (%)": actual_pct,
            "Benford Expected (%)": expected_pct,
            "Variance (%)": diff,
            "Audit Classification": anomaly_flag
        })
        
    return pd.DataFrame(benford_data)

def run_forensic_journal_analytics(je_df=None):
    """
    Scans journal entry dataset and extracts Exception Population.
    """
    if je_df is None:
        try:
            je_df = pd.read_excel("sample_data/journal_entries.xlsx")
        except Exception:
            return pd.DataFrame(), {}, {}
    
    # Filter exceptions
    exceptions = je_df[je_df["Exception Classification"] != "Normal"].copy()
    
    total_entries = len(je_df)
    total_exceptions = len(exceptions)
    total_exception_value = exceptions["Amount (INR)"].sum() / 1e7  # INR Cr
    
    summary = {
        "Total Journal Entries Scanned": total_entries,
        "Total Exception Entries Flagged": total_exceptions,
        "Exception Percentage (%)": round((total_exceptions / total_entries) * 100, 1),
        "Total Value of Exception Population": f"INR {total_exception_value:.2f} Cr"
    }
    
    type_counts = exceptions["Exception Classification"].value_counts().to_dict()
    benford_df = calculate_benfords_law_distribution(je_df)
    
    return exceptions, summary, benford_df
