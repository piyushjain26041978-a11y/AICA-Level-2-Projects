# M&A COPILOT AI — LIVE DEMO SCRIPT FOR ICAI EVALUATORS

## Step 1: Launch Application
1. Double-click `run_app.bat` or execute `streamlit run app.py` in Windows PowerShell / Command Prompt.
2. The browser automatically opens to `http://localhost:8501`.

## Step 2: Review Executive Dashboard (Tab 1)
- Point out the top KPI cards: Base EV (INR 250.0 Cr), Indicative Equity Value (INR 194.5 Cr), Adjusted EBITDA (INR 16.95 Cr), Tax Exposure (INR 8.07 Cr), Overall Risk Score (72.8/100 HIGH RISK).
- Highlight the revenue growth slowing down (+7.1% in FY25) and CFO/EBITDA conversion dropping to 30%.

## Step 3: Inspect Data Room (Tab 2)
- Show the indexed sample documents (`financials.xlsx`, `gst_books.xlsx`, `journal_entries.xlsx`, `Demo_Legal_Memo.txt`).
- Demonstrate document chunk previewing with exact source tags.

## Step 4: Examine QoE Engine & Working Capital (Tabs 4 & 5)
- Show the Reported EBITDA (INR 26.0 Cr) -> Net Adjustments (-INR 9.05 Cr) -> Adjusted EBITDA (INR 16.95 Cr).
- Show the CA guardrail wording: *"Potential adjustment — subject to validation"*.
- Review the Working Capital Peg Analysis (Actual NWC INR 39.3 Cr vs Peg INR 28.5 Cr = INR 10.8 Cr adjustment).

## Step 5: Review GST Reconciliation & Related Parties (Tabs 6 & 8)
- Show turnover mismatch (INR 6.80 Cr) and unmatched GSTR-2A ITC claim (INR 2.05 Cr).
- Review Related Party transactions (INR 16.10 Cr total volume, 10.9% of sales).

## Step 6: Explore Forensic Journal Analytics & Deal Bridge (Tabs 9 & 10)
- Inspect the 8 exception journal entries flagged (round sums, post-closing entries, privileged user postings).
- Demonstrate the Dynamic Scenario Simulator by adjusting Revenue Downside slider and showing the Equity Value updating in real-time.

## Step 7: Test AI Copilot & RAG Retrieval (Tab 12)
- Select the question: *"What are the top five risks affecting valuation?"*
- Click **Ask AI Copilot** and review the generated response with explicit source citations: `[Source: Financials.xlsx | Sheet P&L]`.

## Step 8: Multi-Agent Audit & Report Generation (Tabs 14 & 15)
- Click **Run Multi-Agent Audit Panel** to execute all 9 specialist AI agents and view the M&A Lead Agent synthesis.
- Go to Tab 15 and click **Generate 14-Sheet Excel Workbook** and **Generate PDF Report**. Download and inspect the outputs.
