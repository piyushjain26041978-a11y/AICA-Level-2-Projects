# ICAI AICA LEVEL-2 PROJECT SYNOPSIS

**Project Title**: M&A Copilot — AI-Powered Due Diligence, Risk Identification & Deal Intelligence Platform  
**Tagline**: From Data Room to Deal Intelligence  
**Target User**: Chartered Accountants, Auditors, Valuation Experts, M&A Advisors  

---

## 1. Problem Statement & Business Need
In M&A transactions, financial due diligence teams must analyze hundreds of complex documents in short timeframes. Traditional manual verification of financial statements, GST returns, journal entries, legal memos, and related-party registers is time-intensive and vulnerable to oversight. 

## 2. Proposed AI Solution
M&A Copilot AI provides an automated, decision-support platform that ingests transaction data rooms, performs ratio analytics, reconciles GST/Tax filings, flags forensic journal anomalies, evaluates Quality of Earnings (QoE), and computes an Enterprise Value to Equity Value Bridge with dynamic scenario testing.

## 3. Technology Stack
- **Language**: Python 3.10+
- **Frontend**: Streamlit
- **Analytics & Data**: Pandas, NumPy, OpenPyXL
- **Document Parsers**: PyMuPDF (PDF), python-docx (DOCX), OpenPyXL (Excel)
- **AI & RAG Architecture**: Scikit-Learn TF-IDF Cosine Similarity (Offline Mode) + OpenAI API (Online Mode)
- **Reporting**: ReportLab (PDF), OpenPyXL (14-sheet Excel), TXT

## 4. Key Platform Modules
1. Executive Dashboard (KPIs, Charts, Risk Score)
2. Data Room Ingestion & Citation Indexer
3. Financial Engine (P&L, BS, Cash Flow, Ratios)
4. Quality of Earnings (QoE) Normalization Bridge
5. Working Capital & NWC Peg Analysis Engine
6. Indirect Tax (GST 2A/3B) & Income Tax DD
7. Commercial & Customer Concentration Engine (HHI Index)
8. Related Party & Governance Audit Register
9. Forensic Journal Analytics (Benford / Exception Population)
10. Deal Value Bridge & Dynamic Scenario Simulator
11. Explainable 0-100 Risk Centre
12. Conversational RAG Copilot
13. Auto Management DD Question Generator
14. Multi-Agent Specialist Panel
15. Human-in-the-Loop Audit Trail & Report Exporter

## 5. Professional & Ethical Safeguards
- Strictly decision-support: Does not replace auditor or CA judgment.
- Mandatory Source Attribution: Every factual claim cites `[Source: filename | Page/Sheet]`.
- Anti-Hallucination: Declares "Insufficient evidence" when context is lacking.
