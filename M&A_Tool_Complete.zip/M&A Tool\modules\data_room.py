"""
Data Room Ingestion & Text Chunking Engine
Extracts text from PDF, DOCX, XLSX, CSV, and TXT documents while preserving page/sheet metadata.
"""
import os
import pandas as pd

def extract_pdf_chunks(file_path, file_name):
    chunks = []
    try:
        import fitz  # PyMuPDF
        doc = fitz.open(file_path)
        for page_num in range(len(doc)):
            page = doc[page_num]
            text = page.get_text()
            if text.strip():
                chunks.append({
                    "doc_name": file_name,
                    "doc_type": "PDF",
                    "location": f"Page {page_num + 1}",
                    "text": text.strip(),
                    "source_tag": f"[Source: {file_name} | Page {page_num + 1}]"
                })
        doc.close()
    except Exception as e:
        chunks.append({
            "doc_name": file_name,
            "doc_type": "PDF",
            "location": "Error",
            "text": f"Error extracting PDF: {str(e)}",
            "source_tag": f"[Source: {file_name}]"
        })
    return chunks

def extract_docx_chunks(file_path, file_name):
    chunks = []
    try:
        import docx
        doc = docx.Document(file_path)
        full_text = []
        for p in doc.paragraphs:
            if p.text.strip():
                full_text.append(p.text.strip())
        
        # Group into ~1000 char chunks
        combined = "\n".join(full_text)
        chunk_size = 1000
        for i in range(0, len(combined), chunk_size):
            sub_text = combined[i:i+chunk_size]
            section_num = (i // chunk_size) + 1
            chunks.append({
                "doc_name": file_name,
                "doc_type": "DOCX",
                "location": f"Section {section_num}",
                "text": sub_text,
                "source_tag": f"[Source: {file_name} | Section {section_num}]"
            })
    except Exception as e:
        chunks.append({
            "doc_name": file_name,
            "doc_type": "DOCX",
            "location": "Error",
            "text": f"Error extracting DOCX: {str(e)}",
            "source_tag": f"[Source: {file_name}]"
        })
    return chunks

def extract_excel_chunks(file_path, file_name):
    chunks = []
    try:
        xl = pd.ExcelFile(file_path)
        for sheet_name in xl.sheet_names:
            df = xl.parse(sheet_name)
            sheet_text = f"Sheet: {sheet_name}\n" + df.to_string(index=False)
            chunks.append({
                "doc_name": file_name,
                "doc_type": "Excel",
                "location": f"Sheet {sheet_name}",
                "text": sheet_text,
                "source_tag": f"[Source: {file_name} | Sheet {sheet_name}]"
            })
    except Exception as e:
        chunks.append({
            "doc_name": file_name,
            "doc_type": "Excel",
            "location": "Error",
            "text": f"Error extracting Excel: {str(e)}",
            "source_tag": f"[Source: {file_name}]"
        })
    return chunks

def extract_text_chunks(file_path, file_name):
    chunks = []
    try:
        with open(file_path, "r", encoding="utf-8", errors="ignore") as f:
            text = f.read()
        chunk_size = 1200
        for i in range(0, len(text), chunk_size):
            sub_text = text[i:i+chunk_size]
            part_num = (i // chunk_size) + 1
            chunks.append({
                "doc_name": file_name,
                "doc_type": "TXT/CSV",
                "location": f"Part {part_num}",
                "text": sub_text,
                "source_tag": f"[Source: {file_name} | Part {part_num}]"
            })
    except Exception as e:
        chunks.append({
            "doc_name": file_name,
            "doc_type": "TXT",
            "location": "Error",
            "text": f"Error reading text file: {str(e)}",
            "source_tag": f"[Source: {file_name}]"
        })
    return chunks

def process_data_room_directory(folder_path="sample_data"):
    all_chunks = []
    if not os.path.exists(folder_path):
        return all_chunks
    
    for root, dirs, files in os.walk(folder_path):
        for file in files:
            file_path = os.path.join(root, file)
            ext = os.path.splitext(file)[1].lower()
            if ext == ".pdf":
                all_chunks.extend(extract_pdf_chunks(file_path, file))
            elif ext in [".docx", ".doc"]:
                all_chunks.extend(extract_docx_chunks(file_path, file))
            elif ext in [".xlsx", ".xls"]:
                all_chunks.extend(extract_excel_chunks(file_path, file))
            elif ext in [".txt", ".csv"]:
                all_chunks.extend(extract_text_chunks(file_path, file))
    return all_chunks
