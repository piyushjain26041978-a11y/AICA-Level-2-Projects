"""
Multi-Agent Architecture Engine
Executes 9 Specialist AI Agents (Financial, QoE, Tax, GST, Commercial, Related Party, Forensic, Legal, Valuation)
and 1 M&A Lead Agent for synthesis, deduplication, and executive summary generation.
"""
import pandas as pd

def run_specialist_agents():
    """
    Simulates outputs from 9 Specialist AI Agents.
    """
    agents_output = {
        "Financial Agent": {
            "Agent Name": "Financial & Cash Flow Agent",
            "Key Finding": "Working capital bloat (+44% receivables growth) severely impacted cash conversion (CFO/EBITDA dropped to 30%).",
            "Evidence": "[Source: Financials.xlsx | P&L & Cash Flow]",
            "Risk Level": "HIGH",
            "Deal Impact": "Reduces free cash flow available for debt servicing post-acquisition.",
            "Recommended Action": "Incorporate INR 10.8 Cr Working Capital Adjustment in Equity Bridge."
        },
        "QoE Agent": {
            "Agent Name": "Quality of Earnings (QoE) Agent",
            "Key Finding": "Reported EBITDA of INR 26.0 Cr includes INR 9.05 Cr of non-operating and unverified promoter expense items.",
            "Evidence": "[Source: QoE Engine & Journal_Entries.xlsx]",
            "Risk Level": "CRITICAL",
            "Deal Impact": "Adjusted EBITDA is INR 16.95 Cr, reducing Enterprise Value by up to INR 86.8 Cr.",
            "Recommended Action": "Base valuation strictly on Normalised/Adjusted EBITDA of INR 16.95 Cr."
        },
        "Tax Agent": {
            "Agent Name": "Income Tax & Disputes Agent",
            "Key Finding": "Disallowance of Sec 80IA tax exemption & Transfer Pricing additions created INR 7.75 Cr in contingent liabilities.",
            "Evidence": "[Source: Tax_Data.xlsx | AY 2021-22]",
            "Risk Level": "HIGH",
            "Deal Impact": "Potential cash outflow upon adverse ITAT order.",
            "Recommended Action": "Seek 100% indemnity and indemnity escrow account in SPA."
        },
        "GST Agent": {
            "Agent Name": "GST & Indirect Tax Agent",
            "Key Finding": "Turnover mismatch of INR 6.80 Cr between Books and GSTR-3B with unmatched GSTR-2A ITC claim of INR 2.05 Cr.",
            "Evidence": "[Source: GST_Books.xlsx vs GST_Return.xlsx]",
            "Risk Level": "HIGH",
            "Deal Impact": "Indicative tax liability and penalty exposure of INR 3.27 Cr.",
            "Recommended Action": "Deduct INR 3.27 Cr from purchase price or hold in tax escrow."
        },
        "Commercial Agent": {
            "Agent Name": "Commercial & Market Agent",
            "Key Finding": "37.0% customer revenue concentration in Apex Global Corp whose contract expires in Dec 2025.",
            "Evidence": "[Source: Customer_Sales.xlsx]",
            "Risk Level": "CRITICAL",
            "Deal Impact": "Loss of top customer would reduce EBITDA by INR 9.6 Cr.",
            "Recommended Action": "Condition Precedent (CP) for signed 3-year contract renewal prior to deal closing."
        },
        "Related Party Agent": {
            "Agent Name": "Related Party & Governance Agent",
            "Key Finding": "INR 16.10 Cr in related party transactions including unverified consultancy fees and 30% above-market lease rents.",
            "Evidence": "[Source: Related_Party_Master.xlsx]",
            "Risk Level": "CRITICAL",
            "Deal Impact": "Value leakage to promoter entities.",
            "Recommended Action": "Mandatory termination of non-essential related party agreements at closing."
        },
        "Forensic Agent": {
            "Agent Name": "Forensic & Journal Analytics Agent",
            "Key Finding": "Year-end manual post-closing journal entry JV-2025-901 crediting unbilled revenue by INR 55.0 Lakhs posted by SUPERADMIN.",
            "Evidence": "[Source: Journal_Entries.xlsx | JV-2025-901]",
            "Risk Level": "HIGH",
            "Deal Impact": "Potential premature revenue recognition.",
            "Recommended Action": "Verify customer acceptance certificates and audit trail."
        },
        "Legal Risk Agent": {
            "Agent Name": "Legal & Regulatory Risk Agent",
            "Key Finding": "High Court environmental show-cause notice demanding INR 3.50 Cr for Tarapur Unit-2.",
            "Evidence": "[Source: Demo_Legal_Memo.txt | Section 1]",
            "Risk Level": "MODERATE",
            "Deal Impact": "Plant shutdown or environmental compensation penalty.",
            "Recommended Action": "Obtain environmental compliance certificate prior to closing."
        },
        "Deal Valuation Agent": {
            "Agent Name": "Deal Value & Bridge Agent",
            "Key Finding": "Calculated Indicative Equity Value is INR 194.6 Cr vs Base EV of INR 250.0 Cr due to Net Debt, WC, and Tax deductions.",
            "Evidence": "[Source: Deal Value Engine]",
            "Risk Level": "HIGH",
            "Deal Impact": "Total deal price adjustment required: INR 55.4 Cr.",
            "Recommended Action": "Present revised Equity Value Bridge to Target Board."
        }
    }
    return agents_output

def run_lead_agent_synthesis():
    """
    Lead Agent consolidates and synthesizes outputs from all specialist agents.
    """
    specialist_outputs = run_specialist_agents()
    
    summary_text = (
        "### M&A LEAD AGENT EXECUTIVE SYNTHESIS REPORT\n\n"
        "**Target Company**: Apex Industrial Solutions Ltd | **Deal Risk Category**: HIGH (Score: 72.8/100)\n\n"
        "#### 1. Executive Summary & Top Findings\n"
        "The Multi-Agent Review Panel has conducted an exhaustive due diligence audit across 9 functional dimensions. "
        "The primary deal-breaker risks center around **Quality of Earnings (EBITDA Overstatement)**, **Customer Concentration**, "
        "and **Unverified Related-Party Leakage**.\n\n"
        "#### 2. Critical Deal Value Adjustments Summary\n"
        "- **Base Negotiated Enterprise Value (EV)**: INR 250.00 Cr\n"
        "- **Net Debt Deduction**: -INR 32.00 Cr\n"
        "- **Working Capital Peg Adjustment**: -INR 10.80 Cr\n"
        "- **Tax & GST Risk Exposure Deduction**: -INR 8.07 Cr\n"
        "- **Debt-Like Obligations (Gratuity/Stock)**: -INR 4.65 Cr\n"
        "→ **Indicative Equity Value**: **INR 194.48 Cr** *(Total Haircut: 22.2%)*\n\n"
        "#### 3. Key Conditions Precedent (CP) Recommended for SPA\n"
        "1. Signed 3-year renewal of commercial contract with Apex Global Corp (37% sales share).\n"
        "2. Termination of unverified KMP Consulting advisory contract (saving INR 3.80 Cr/yr).\n"
        "3. Establishment of INR 10.0 Cr Tax & Indemnity Escrow Account for ITAT & GST disputes.\n"
        "4. Actuarial funding of gratuity liability under AS-15 / IND AS 19."
    )
    
    table_rows = []
    for k, v in specialist_outputs.items():
        table_rows.append(v)
    
    return summary_text, pd.DataFrame(table_rows)
