"""
Financial Analysis Engine
Analyzes P&L, Balance Sheet, and Cash Flow metrics, ratios, trends, DuPont Analysis, and financial risk indicators.
"""
import pandas as pd
import numpy as np

def run_dupont_analysis():
    """
    Computes 3-step DuPont Analysis breakdown of ROE over FY23, FY24, FY25.
    ROE = Net Profit Margin x Asset Turnover x Financial Leverage
    """
    dupont = [
        {
            "Financial Year": "FY23",
            "Net Profit (PAT) (Cr)": 13.1,
            "Revenue (Cr)": 120.5,
            "Net Profit Margin (%)": 10.87,
            "Total Assets (Cr)": 89.0,
            "Asset Turnover (x)": 1.35,
            "Total Equity (Cr)": 42.5,
            "Financial Leverage (x)": 2.09,
            "Calculated ROE (%)": 30.82
        },
        {
            "Financial Year": "FY24",
            "Net Profit (PAT) (Cr)": 14.6,
            "Revenue (Cr)": 138.2,
            "Net Profit Margin (%)": 10.56,
            "Total Assets (Cr)": 104.6,
            "Asset Turnover (x)": 1.32,
            "Total Equity (Cr)": 51.1,
            "Financial Leverage (x)": 2.05,
            "Calculated ROE (%)": 28.57
        },
        {
            "Financial Year": "FY25",
            "Net Profit (PAT) (Cr)": 12.2,
            "Revenue (Cr)": 148.0,
            "Net Profit Margin (%)": 8.24,
            "Total Assets (Cr)": 128.3,
            "Asset Turnover (x)": 1.15,
            "Total Equity (Cr)": 58.3,
            "Financial Leverage (x)": 2.20,
            "Calculated ROE (%)": 20.93
        }
    ]
    return pd.DataFrame(dupont)

def run_financial_analysis(pnl_df=None, bs_df=None, cf_df=None):
    """
    Computes key financial metrics and ratios over FY23, FY24, FY25.
    """
    metrics = []
    
    # Revenue Analysis
    rev_23, rev_24, rev_25 = 120.5, 138.2, 148.0
    rev_growth_24 = ((rev_24 - rev_23) / rev_23) * 100
    rev_growth_25 = ((rev_25 - rev_24) / rev_24) * 100
    
    metrics.append({
        "Metric": "Revenue from Operations",
        "FY23": f"INR {rev_23:.1f} Cr",
        "FY24": f"INR {rev_24:.1f} Cr",
        "FY25": f"INR {rev_25:.1f} Cr",
        "Trend / Growth": f"FY24: +{rev_growth_24:.1f}%, FY25: +{rev_growth_25:.1f}%",
        "Risk Flag": "MODERATE" if rev_growth_25 < rev_growth_24 else "LOW",
        "Review Required": "Growth slowing down from 14.7% to 7.1% YoY in FY25."
    })
    
    # EBITDA Analysis
    ebitda_23, ebitda_24, ebitda_25 = 25.1, 28.0, 26.0
    margin_23 = (ebitda_23 / rev_23) * 100
    margin_24 = (ebitda_24 / rev_24) * 100
    margin_25 = (ebitda_25 / rev_25) * 100
    
    metrics.append({
        "Metric": "Reported EBITDA & Margin",
        "FY23": f"INR {ebitda_23:.1f} Cr ({margin_23:.1f}%)",
        "FY24": f"INR {ebitda_24:.1f} Cr ({margin_24:.1f}%)",
        "FY25": f"INR {ebitda_25:.1f} Cr ({margin_25:.1f}%)",
        "Trend / Growth": f"Margin: 20.8% → 20.3% → 17.6%",
        "Risk Flag": "HIGH",
        "Review Required": "EBITDA margin compressed by 270 bps in FY25 despite revenue growth."
    })
    
    # CFO to EBITDA Conversion
    cfo_23, cfo_24, cfo_25 = 18.4, 14.2, 7.8
    conv_23 = (cfo_23 / ebitda_23) * 100
    conv_24 = (cfo_24 / ebitda_24) * 100
    conv_25 = (cfo_25 / ebitda_25) * 100
    
    metrics.append({
        "Metric": "Cash Flow from Operations (CFO)",
        "FY23": f"INR {cfo_23:.1f} Cr ({conv_23:.0f}%)",
        "FY24": f"INR {cfo_24:.1f} Cr ({conv_24:.0f}%)",
        "FY25": f"INR {cfo_25:.1f} Cr ({conv_25:.0f}%)",
        "Trend / Growth": f"CFO/EBITDA dropped from 73% to 30%",
        "Risk Flag": "CRITICAL",
        "Review Required": "Severe cash conversion deterioration. Profits not converting into cash flow."
    })
    
    # Receivable Days (DSO)
    rec_23, rec_24, rec_25 = 22.4, 28.6, 41.2
    dso_23 = round((rec_23 / rev_23) * 365)
    dso_24 = round((rec_24 / rev_24) * 365)
    dso_25 = round((rec_25 / rev_25) * 365)
    
    metrics.append({
        "Metric": "Receivable Days (DSO)",
        "FY23": f"{dso_23} Days (INR {rec_23} Cr)",
        "FY24": f"{dso_24} Days (INR {rec_24} Cr)",
        "FY25": f"{dso_25} Days (INR {rec_25} Cr)",
        "Trend / Growth": f"DSO surged from 68 to 102 days (+34 days)",
        "Risk Flag": "CRITICAL",
        "Review Required": "Receivables growing at +44% YoY vs Sales +7.1%. High credit risk."
    })

    # Inventory Days (DIO)
    inv_23, inv_24, inv_25 = 15.2, 18.5, 24.8
    dio_23 = round((inv_23 / 65.0) * 365)
    dio_24 = round((inv_24 / 74.8) * 365)
    dio_25 = round((inv_25 / 82.5) * 365)

    metrics.append({
        "Metric": "Inventory Days (DIO)",
        "FY23": f"{dio_23} Days (INR {inv_23} Cr)",
        "FY24": f"{dio_24} Days (INR {inv_24} Cr)",
        "FY25": f"{dio_25} Days (INR {inv_25} Cr)",
        "Trend / Growth": f"DIO increased from 85 to 110 days (+25 days)",
        "Risk Flag": "HIGH",
        "Review Required": "Significant inventory build-up. Risk of slow-moving/obsolete stock."
    })

    # Net Debt & Net Debt / EBITDA
    gross_debt_25, cash_25 = 36.5, 4.5
    net_debt_25 = gross_debt_25 - cash_25
    nd_ebitda_25 = net_debt_25 / ebitda_25

    metrics.append({
        "Metric": "Net Debt & Net Debt/EBITDA",
        "FY23": "INR 15.4 Cr (0.61x)",
        "FY24": "INR 19.0 Cr (0.68x)",
        "FY25": f"INR {net_debt_25:.1f} Cr ({nd_ebitda_25:.2f}x)",
        "Trend / Growth": "Net Debt jumped +68% in FY25",
        "Risk Flag": "HIGH",
        "Review Required": "Increased leverage to fund working capital gap."
    })
    
    return pd.DataFrame(metrics)
