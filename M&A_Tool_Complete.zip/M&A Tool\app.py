"""
M&A Copilot — AI-Powered Due Diligence, Risk Identification & Deal Intelligence Platform
Main Streamlit Application
"""
import os
import pandas as pd
import numpy as np
import streamlit as st
from datetime import datetime

# Import Custom Modules
from config import APP_TITLE, APP_TAGLINE, APP_VERSION, DISCLAIMER_TEXT, CUSTOM_CSS, COLORS, RISK_CATEGORIES
from modules.data_room import process_data_room_directory
from modules.rag_engine import RAGEngine
from modules.financial_engine import run_financial_analysis, run_dupont_analysis
from modules.qoe_engine import run_qoe_analysis
from modules.working_capital_engine import run_working_capital_analysis
from modules.tax_gst_engine import run_gst_reconciliation, get_income_tax_summary
from modules.related_party_engine import run_related_party_analysis
from modules.forensic_engine import run_forensic_journal_analytics
from modules.commercial_engine import run_commercial_analysis
from modules.deal_value_engine import build_deal_value_bridge
from modules.scenario_lab import run_scenario_simulation
from modules.valuation_engine import run_dcf_valuation, run_multi_method_valuation_summary
from modules.risk_scoring import calculate_overall_risk_score
from modules.ai_copilot import RAGEngine
from modules.management_questions import generate_management_questions
from modules.multi_agent import run_lead_agent_synthesis, run_specialist_agents
from modules.human_in_loop import init_review_trail, update_review_decision
from modules.dd_checklist import init_dd_checklist, update_checklist_item, calculate_checklist_progress
from modules.report_generator import generate_txt_report, generate_excel_report, generate_pdf_report

# Page Config
st.set_page_config(
    page_title="M&A Copilot AI",
    page_icon="💼",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Apply CSS & PWA Injector
st.markdown(CUSTOM_CSS, unsafe_allow_html=True)
st.markdown("""
<link rel="manifest" href="/manifest.json">
<script>
  if ('serviceWorker' in navigator) {
    navigator.serviceWorker.register('/sw.js');
  }
</script>
""", unsafe_allow_html=True)

# Initialize Session State
if "chunks" not in st.session_state:
    st.session_state.chunks = process_data_room_directory("sample_data")
if "rag_engine" not in st.session_state:
    st.session_state.rag_engine = RAGEngine(st.session_state.chunks)
if "review_trail" not in st.session_state:
    st.session_state.review_trail = init_review_trail()
if "dd_checklist" not in st.session_state:
    st.session_state.dd_checklist = init_dd_checklist()

# Sidebar Setup
with st.sidebar:
    st.image("https://img.icons8.com/color/96/briefcase.png", width=64)
    st.title("M&A Copilot AI")
    st.caption(APP_TAGLINE)
    st.markdown("---")
    
    st.subheader("⚙️ Deal Configuration")
    target_company = st.text_input("Target Company", value="Apex Industrial Solutions Ltd")
    acquirer_company = st.text_input("Acquirer Entity", value="Strategic Investment Partners")
    industry_type = st.selectbox("Industry Sector", ["Manufacturing / Chemicals", "Technology / SaaS", "Healthcare", "Consumer Goods", "Infrastructure"])
    base_ev_input = st.number_input("Negotiated Base EV (INR Cr)", value=250.0, step=5.0)
    normalised_wc_peg_input = st.number_input("Normalised WC Peg (INR Cr)", value=28.5, step=1.0)
    
    st.markdown("---")
    st.subheader("🤖 AI Model Configuration")
    ai_mode = st.radio("AI Execution Mode", ["Offline Analytical (TF-IDF)", "Online OpenAI LLM"])
    openai_api_key = ""
    if ai_mode == "Online OpenAI LLM":
        openai_api_key = st.text_input("OpenAI API Key", type="password", help="Enter API key for GPT-4o RAG generation.")
    
    st.markdown("---")
    st.subheader("🔄 Data Management")
    if st.button("Reset Data to Default Baseline", help="Re-generates sample data and resets Data Room"):
        import subprocess
        try:
            subprocess.run(["python", "create_sample_data.py"], check=True)
        except Exception:
            pass
        st.session_state.chunks = process_data_room_directory("sample_data")
        st.session_state.rag_engine = RAGEngine(st.session_state.chunks)
        st.session_state.review_trail = init_review_trail()
        st.success("Data Room & Sample Datasets successfully reset to default baseline!")
        st.rerun()

    st.markdown("---")
    st.info(f"**Version**: {APP_VERSION}\n\n**Data Room Chunks**: {len(st.session_state.chunks)}")

# Main Header
st.markdown(f"## 💼 {target_company} — M&A Due Diligence & Deal Intelligence")
st.caption(f"Prepared for: **{acquirer_company}** | Sector: **{industry_type}** | Status: **Comprehensive AI DD Active**")

# Top Navigation Tabs
tabs = st.tabs([
    "📊 Dashboard",
    "✅ DD Checklist",
    "📁 Data Room",
    "📈 Financials",
    "⚖️ Quality of Earnings",
    "🔄 Working Capital",
    "🏛️ GST & Tax DD",
    "🏢 Commercial",
    "🤝 Related Parties",
    "🔍 Forensic Analytics",
    "🎯 Deal Bridge & Scenarios",
    "🏆 Multi-Method Valuation",
    "⚠️ Risk Centre",
    "💬 AI Copilot",
    "❓ DD Questions",
    "🤖 Multi-Agent Review",
    "📋 Review & Reports"
])

# ----------------------------------------------------
# TAB 1: EXECUTIVE DASHBOARD
# ----------------------------------------------------
with tabs[0]:
    st.subheader("Executive Deal Intelligence Overview")
    
    risk_df, risk_summary = calculate_overall_risk_score()
    bridge_df, bridge_summary = build_deal_value_bridge(base_ev=base_ev_input, wc_adj=10.8, tax_exp=8.07)
    
    # KPI Cards Row
    col1, col2, col3, col4, col5 = st.columns(5)
    with col1:
        st.markdown(f"""
        <div class="kpi-card">
            <div class="kpi-title">Base EV</div>
            <div class="kpi-value">INR {base_ev_input:.1f} Cr</div>
            <div class="kpi-subtext">Negotiated Baseline</div>
        </div>
        """, unsafe_allow_html=True)
    
    with col2:
        st.markdown(f"""
        <div class="kpi-card">
            <div class="kpi-title">Indicative Equity Value</div>
            <div class="kpi-value">INR {bridge_summary['Indicative Equity Value']:.1f} Cr</div>
            <div class="kpi-subtext" style="color:#EF4444;">Haircut: {bridge_summary['EV to Equity Value Haircut (%)']}%</div>
        </div>
        """, unsafe_allow_html=True)
        
    with col3:
        st.markdown(f"""
        <div class="kpi-card">
            <div class="kpi-title">Adjusted EBITDA</div>
            <div class="kpi-value">INR 16.95 Cr</div>
            <div class="kpi-subtext" style="color:#F59E0B;">Reported: INR 26.0 Cr</div>
        </div>
        """, unsafe_allow_html=True)
        
    with col4:
        st.markdown(f"""
        <div class="kpi-card">
            <div class="kpi-title">Tax & GST Exposure</div>
            <div class="kpi-value">INR 8.07 Cr</div>
            <div class="kpi-subtext" style="color:#EF4444;">4 Major Disputes</div>
        </div>
        """, unsafe_allow_html=True)
        
    with col5:
        st.markdown(f"""
        <div class="kpi-card">
            <div class="kpi-title">Overall Risk Score</div>
            <div class="kpi-value" style="color:#EF4444;">{risk_summary['Overall Risk Score']} / 100</div>
            <div class="kpi-subtext"><span class="badge-high">HIGH RISK</span></div>
        </div>
        """, unsafe_allow_html=True)

    st.markdown("<br>", unsafe_allow_html=True)
    
    # Row 1: Financial Trends & Risk Distribution Graphics
    c_left, c_right = st.columns(2)
    with c_left:
        st.markdown("#### 📈 Revenue, EBITDA & CFO Trajectory (FY23 - FY25)")
        chart_data = pd.DataFrame({
            "Financial Year": ["FY23", "FY24", "FY25"],
            "Revenue (INR Cr)": [120.5, 138.2, 148.0],
            "Reported EBITDA (INR Cr)": [25.1, 28.0, 26.0],
            "Cash Flow from Operations (CFO)": [18.4, 14.2, 7.8]
        }).set_index("Financial Year")
        st.line_chart(chart_data)
        
    with c_right:
        st.markdown("#### ⚠️ Risk Score Breakdown Across 15 DD Categories")
        st.bar_chart(risk_df.set_index("Category")["Score (0-100)"])

    st.markdown("---")
    
    # Row 2: EV to Equity Bridge & QoE Normalization Graphics
    c_b1, c_b2 = st.columns(2)
    with c_b1:
        st.markdown("#### 🎯 Enterprise Value to Equity Value Bridge Waterfall")
        bridge_chart = pd.DataFrame({
            "Bridge Component": ["Base EV", "Net Debt", "WC Peg Adj", "Tax Risk", "Debt-like Items", "Equity Value"],
            "Amount (INR Cr)": [base_ev_input, -32.0, -10.8, -8.07, -4.65, bridge_summary['Indicative Equity Value']]
        }).set_index("Bridge Component")
        st.bar_chart(bridge_chart)
        
    with c_b2:
        st.markdown("#### ⚖️ Reported vs Adjusted EBITDA Normalization")
        qoe_chart = pd.DataFrame({
            "EBITDA Metric": ["Reported EBITDA", "Asset Sale / Subsidy", "Unverified KMP Fee", "Promoter Personal Exp", "Adjusted EBITDA"],
            "Value (INR Cr)": [26.0, -4.20, +3.80, +1.20, 16.95]
        }).set_index("EBITDA Metric")
        st.bar_chart(qoe_chart)
        
    st.markdown("---")
    st.markdown("### 🚩 Top Deal Red Flags & Executive Action Required")
    st.markdown("""
    - 🚩 **EBITDA Quality Overstatement**: INR 9.05 Cr of non-operating and unverified items in reported EBITDA.
    - 🚩 **Receivables Bloat & CFO Drop**: DSO increased by +34 days to 102 days; CFO/EBITDA conversion crashed from 73% to 30%.
    - 🚩 **Customer Concentration**: Top customer Apex Global Corp accounts for 37% of revenue; contract expires Dec 2025.
    - 🚩 **Related Party Value Leakage**: INR 16.10 Cr in transactions including unverified consultancy fees and above-market rents.
    """)

# ----------------------------------------------------
# TAB 2: DD CHECKLIST & PROGRESS TRACKER
# ----------------------------------------------------
with tabs[1]:
    st.subheader("✅ Master Due Diligence Checklist & Verification Tracker")
    st.write("Track mandatory due diligence audit procedures, assign CA reviewers, and sign off completed DD tasks.")
    
    progress_info = calculate_checklist_progress(st.session_state.dd_checklist)
    
    # Progress Bar & Metrics
    c_p1, c_p2, c_p3, c_p4 = st.columns(4)
    c_p1.metric("Total DD Tasks", progress_info["Total Tasks"])
    c_p2.metric("Completed Tasks", progress_info["Completed"], delta=f"{progress_info['Completion Percentage']}%")
    c_p3.metric("Tasks In Progress", progress_info["In Progress"])
    c_p4.metric("Pending Tasks", progress_info["Pending"])
    
    st.progress(progress_info["Completion Percentage"] / 100.0)
    st.markdown("<br>", unsafe_allow_html=True)
    
    # Category Filter
    all_categories = ["All Categories"] + list(set([item["Category"] for item in st.session_state.dd_checklist]))
    selected_cat = st.selectbox("Filter DD Procedure by Domain Category:", options=all_categories)
    
    filtered_items = st.session_state.dd_checklist
    if selected_cat != "All Categories":
        filtered_items = [item for item in st.session_state.dd_checklist if item["Category"] == selected_cat]
        
    st.markdown("---")
    st.markdown("#### Interactive Due Diligence Task Matrix")
    
    for item in filtered_items:
        is_completed = item["Status"] == "Completed"
        with st.expander(f"[{item['Item ID']}] {item['Category']} — {item['Task Description'][:70]}... ({'✅ Completed' if is_completed else '⏳ ' + item['Status']})"):
            col_t1, col_t2 = st.columns([3, 1])
            with col_t1:
                st.write(f"**Task Procedure**: {item['Task Description']}")
                st.write(f"**Mandatory Audit Evidence**: `{item['Mandatory Document']}`")
                st.write(f"**Audit Notes / Findings**: {item['Notes']}")
                if is_completed:
                    st.success(f"Signed off by {item['Assigned CA']} on {item['Sign-off Date']}")
            with col_t2:
                new_status = st.selectbox(
                    "Verification Status",
                    ["Pending", "In Progress", "Pending Management Reply", "Completed"],
                    index=["Pending", "In Progress", "Pending Management Reply", "Completed"].index(item["Status"]) if item["Status"] in ["Pending", "In Progress", "Pending Management Reply", "Completed"] else 0,
                    key=f"status_{item['Item ID']}"
                )
                ca_input = st.text_input("Assigned CA", value=item["Assigned CA"], key=f"ca_{item['Item ID']}")
                notes_input = st.text_area("Audit Notes", value=item["Notes"], key=f"notes_{item['Item ID']}")
                
                if st.button(f"Save Sign-off ({item['Item ID']})", key=f"save_{item['Item ID']}"):
                    st.session_state.dd_checklist = update_checklist_item(
                        st.session_state.dd_checklist,
                        item["Item ID"],
                        new_status,
                        notes=notes_input,
                        ca_name=ca_input
                    )
                    st.success(f"Updated status for {item['Item ID']}")
                    st.rerun()

# ----------------------------------------------------
# TAB 3: DATA ROOM
# ----------------------------------------------------
with tabs[2]:
    st.subheader("📁 Transaction Data Room & Ingestion Hub")
    
    st.markdown("""
    <div class="upload-callout">
        <h4 style="margin-top:0; color:#0284C7;">📥 How to Upload Data Room Documents:</h4>
        <ol style="margin-bottom:0;">
            <li><b>Option 1 (Drag & Drop UI):</b> Use the file uploader widget below to upload PDFs, Word docs (DOCX), Excel spreadsheets (XLSX/XLS), CSVs, or TXT legal memos directly.</li>
            <li><b>Option 2 (Local Folder Drop):</b> Place any file inside the <code>sample_data/</code> folder on your computer. The system automatically reads and indexes all files in this directory.</li>
        </ol>
    </div>
    """, unsafe_allow_html=True)
    
    uploaded_files = st.file_uploader("Upload Transaction File(s) to Data Room", accept_multiple_files=True, type=["pdf", "docx", "xlsx", "csv", "txt"], key="dd_room_file_uploader")
    if uploaded_files:
        os.makedirs("sample_data", exist_ok=True)
        for uf in uploaded_files:
            file_path = os.path.join("sample_data", uf.name)
            with open(file_path, "wb") as f:
                f.write(uf.getbuffer())
        st.success(f"Successfully uploaded {len(uploaded_files)} file(s). Re-indexing Data Room...")
        st.session_state.chunks = process_data_room_directory("sample_data")
        st.session_state.rag_engine = RAGEngine(st.session_state.chunks)
        
    st.markdown("---")
    st.markdown("#### Document Index Register")
    
    if st.session_state.chunks:
        doc_df = pd.DataFrame(st.session_state.chunks)
        summary_doc = doc_df.groupby(["doc_name", "doc_type"]).agg(
            Total_Chunks=("text", "count"),
            Locations=("location", lambda x: ", ".join(list(set(x))[:4]))
        ).reset_index()
        st.dataframe(summary_doc, use_container_width=True)
        
        st.markdown("#### Extracted Chunk Inspection")
        selected_doc = st.selectbox("Select Document to Preview Text Chunks", options=doc_df["doc_name"].unique())
        doc_chunks = doc_df[doc_df["doc_name"] == selected_doc]
        for idx, row in doc_chunks.iterrows():
            with st.expander(f"{row['source_tag']} ({len(row['text'])} chars)"):
                st.code(row["text"], language="markdown")
    else:
        st.info("No documents currently indexed in Data Room.")



# ----------------------------------------------------
# TAB 4: FINANCIAL ANALYSIS
# ----------------------------------------------------
with tabs[3]:
    st.subheader("📈 Financial Statement Analysis & Ratio Analytics")
    
    fin_table = run_financial_analysis(None, None, None)
    st.dataframe(fin_table, use_container_width=True)
    
    st.markdown("---")
    st.markdown("### Financial Ratios & Cash Conversion Deep-Dive")
    c1, c2 = st.columns(2)
    with c1:
        st.markdown("#### Receivables & Inventory Ageing Trajectory")
        days_df = pd.DataFrame({
            "Year": ["FY23", "FY24", "FY25"],
            "Receivable Days (DSO)": [68, 76, 102],
            "Inventory Days (DIO)": [85, 90, 110],
            "Payable Days (DPO)": [102, 100, 107]
        }).set_index("Year")
        st.line_chart(days_df)
    with c2:
        st.markdown("#### Cash Conversion Ratio (CFO / EBITDA %)")
        cfo_conv_df = pd.DataFrame({
            "Year": ["FY23", "FY24", "FY25"],
            "CFO / EBITDA (%)": [73.3, 50.7, 30.0]
        }).set_index("Year")
        st.bar_chart(cfo_conv_df)

    st.markdown("---")
    st.markdown("### 🧬 3-Step DuPont Analysis (ROE Decomposition)")
    st.caption("ROE = Net Profit Margin × Asset Turnover × Financial Leverage")
    dupont_df = run_dupont_analysis()
    st.dataframe(dupont_df, use_container_width=True)

# ----------------------------------------------------
# TAB 5: QUALITY OF EARNINGS (QoE)
# ----------------------------------------------------
with tabs[4]:
    st.subheader("⚖️ Quality of Earnings (QoE) Engine")
    st.info("⚠️ Professional Guardrail: All adjustments are tagged as 'Potential adjustment — subject to validation'. Never automatically classify as definitive add-backs.")
    
    adj_df, qoe_summary = run_qoe_analysis()
    
    col1, col2, col3 = st.columns(3)
    col1.metric("Reported FY25 EBITDA", f"INR {qoe_summary['Reported EBITDA']:.2f} Cr")
    col2.metric("Net Potential Adjustments", f"INR {qoe_summary['Net Potential Adjustments']:.2f} Cr", delta="-34.8%")
    col3.metric("Normalised / Adjusted EBITDA", f"INR {qoe_summary['Adjusted EBITDA (Normalised)']:.2f} Cr")
    
    st.markdown("---")
    st.markdown("#### Detailed EBITDA Normalization Schedule")
    st.dataframe(adj_df, use_container_width=True)

# ----------------------------------------------------
# TAB 6: WORKING CAPITAL
# ----------------------------------------------------
with tabs[5]:
    st.subheader("🔄 Working Capital & NWC Peg Analysis")
    
    peg_summary, wc_red_flags = run_working_capital_analysis()
    
    c1, c2, c3 = st.columns(3)
    c1.metric("Actual FY25 Net Working Capital", f"INR {peg_summary['Actual Net Working Capital (NWC)']:.2f} Cr")
    c2.metric("Normalised Working Capital Peg", f"INR {peg_summary['Normalised Working Capital Peg']:.2f} Cr")
    c3.metric("Working Capital Adjustment (Deduction)", f"INR {peg_summary['Working Capital Adjustment (Excess / Shortfall)']:.2f} Cr", delta="-Excess NWC")
    
    st.markdown("---")
    st.markdown("#### Working Capital Red Flags & Overdue Analysis")
    st.dataframe(wc_red_flags, use_container_width=True)

# ----------------------------------------------------
# TAB 7: GST & TAX DD
# ----------------------------------------------------
with tabs[6]:
    st.subheader("🏛️ Indirect Tax (GST) & Direct Tax Due Diligence")
    
    gst_df, gst_summary = run_gst_reconciliation()
    tax_df = get_income_tax_summary()
    
    st.markdown("#### 1. GST Turnover & Input Tax Credit (ITC) Reconciliation")
    st.dataframe(gst_df, use_container_width=True)
    
    c1, c2, c3 = st.columns(3)
    c1.metric("Total Turnover Mismatch", f"INR {gst_summary['Total Turnover Mismatch']:.2f} Cr")
    c2.metric("GST Undischarged Shortfall", f"INR {gst_summary['Total GST Tax Shortfall (Undischarged)']:.2f} Cr")
    c3.metric("Unmatched GSTR-2A ITC Risk", f"INR {gst_summary['Ineligible / Unmatched GSTR-2A ITC Claim']:.2f} Cr")
    
    st.markdown("---")
    st.markdown("#### 2. Income Tax & Customs Contingent Liabilities")
    st.dataframe(tax_df, use_container_width=True)

# ----------------------------------------------------
# TAB 8: COMMERCIAL ANALYSIS
# ----------------------------------------------------
with tabs[7]:
    st.subheader("🏢 Commercial Due Diligence & Concentration Analytics")
    
    cust_df, vendor_df, comm_summary = run_commercial_analysis()
    
    col1, col2, col3, col4 = st.columns(4)
    col1.metric("Top 1 Customer Share", comm_summary["Top 1 Customer Share"])
    col2.metric("Top 3 Customer Share", comm_summary["Top 3 Customer Share"])
    col3.metric("Herfindahl Index (HHI)", comm_summary["Herfindahl Index (HHI)"])
    col4.metric("Top 1 Supplier Share", comm_summary["Top 1 Vendor Share"])
    
    st.markdown("---")
    st.markdown("#### Top Customer Sales & Renewal Status")
    st.dataframe(cust_df, use_container_width=True)
    
    st.markdown("#### Top Supplier Purchases & Procurement Risk")
    st.dataframe(vendor_df, use_container_width=True)

# ----------------------------------------------------
# TAB 9: RELATED PARTIES
# ----------------------------------------------------
with tabs[8]:
    st.subheader("🤝 Related Party & Governance Due Diligence")
    
    rp_df, rp_summary = run_related_party_analysis()
    
    c1, c2 = st.columns(2)
    c1.metric("Total Related Party Volume (FY25)", f"INR {rp_summary['Total Related Party Transaction Volume (FY25)']:.2f} Cr")
    c2.metric("Share of FY25 Revenue", f"{rp_summary['Percentage of FY25 Revenue']}%")
    
    st.markdown("---")
    st.markdown("#### Related Party Register & Arm's Length Evaluation")
    st.dataframe(rp_df, use_container_width=True)

# ----------------------------------------------------
# TAB 10: FORENSIC ANALYTICS
# ----------------------------------------------------
with tabs[9]:
    st.subheader("🔍 Forensic Journal Entry Exception Analytics & Benford's Law")
    
    forensic_df, forensic_summary, benford_df = run_forensic_journal_analytics()
    
    c1, c2, c3 = st.columns(3)
    c1.metric("Entries Scanned", forensic_summary["Total Journal Entries Scanned"])
    c2.metric("Exception Entries Flagged", forensic_summary["Total Exception Entries Flagged"])
    c3.metric("Exception Population Value", forensic_summary["Total Value of Exception Population"])
    
    st.markdown("---")
    st.markdown("#### 1. Flagged Anomaly Journal Population")
    st.dataframe(forensic_df, use_container_width=True)
    
    st.markdown("---")
    st.markdown("#### 2. Benford's Law First-Digit Audit Analysis")
    st.caption("Compares journal entry amount leading digits against theoretical Benford probability (P(d) = log10(1 + 1/d)).")
    if not benford_df.empty:
        st.dataframe(benford_df, use_container_width=True)
        chart_ben = benford_df.set_index("First Digit")[["Actual Frequency (%)", "Benford Expected (%)"]]
        st.bar_chart(chart_ben)

# ----------------------------------------------------
# TAB 11: DEAL BRIDGE & SCENARIO LAB
# ----------------------------------------------------
with tabs[10]:
    st.subheader("🎯 Deal Value Bridge & Dynamic Scenario Simulator")
    
    st.markdown("#### 1. Enterprise Value to Equity Value Bridge")
    bridge_df, bridge_summary = build_deal_value_bridge(base_ev=base_ev_input, wc_adj=10.8, tax_exp=8.07)
    st.dataframe(bridge_df, use_container_width=True)
    
    st.markdown("---")
    st.markdown("#### 2. Dynamic Deal Downside Sensitivity Simulator")
    
    col_s1, col_s2, col_s3 = st.columns(3)
    with col_s1:
        rev_downside = st.slider("Revenue Downside Risk (%)", 0, 30, 10, 5)
    with col_s2:
        margin_press = st.slider("Margin Pressure (bps)", 0, 500, 200, 50)
    with col_s3:
        cust_loss = st.slider("Customer Loss Impact (%)", 0, 40, 15, 5)
        
    scen_df = run_scenario_simulation(
        base_ev=base_ev_input,
        rev_downside_pct=rev_downside,
        margin_pressure_bps=margin_press,
        customer_loss_pct=cust_loss
    )
    st.dataframe(scen_df, use_container_width=True)
    
    st.markdown("---")
    st.markdown("#### 3. EV / EBITDA Valuation Multiple Sensitivity Matrix")
    st.caption("Evaluates Enterprise Value & Equity Value under varying market transaction multiples.")
    
    multiples = [7.0, 8.0, 9.0, 9.61, 10.0, 11.0, 12.0]
    sens_data = []
    adj_ebitda_val = 16.95
    rep_ebitda_val = 26.00
    net_deductions = 32.0 + 10.8 + 8.07 + 4.65  # 55.52 Cr
    
    for m in multiples:
        ev_rep = rep_ebitda_val * m
        eq_rep = ev_rep - net_deductions
        ev_adj = adj_ebitda_val * m
        eq_adj = ev_adj - net_deductions
        sens_data.append({
            "EV/EBITDA Multiple": f"{m:.1f}x",
            "Reported EV (Cr)": round(ev_rep, 2),
            "Reported EqV (Cr)": round(eq_rep, 2),
            "Adjusted EV (Cr)": round(ev_adj, 2),
            "Adjusted EqV (Cr)": round(eq_adj, 2),
            "Valuation Gap (Cr)": round(ev_rep - ev_adj, 2)
        })
    st.dataframe(pd.DataFrame(sens_data), use_container_width=True)

# ----------------------------------------------------
# TAB 12: MULTI-METHOD VALUATION SUITE
# ----------------------------------------------------
with tabs[11]:
    st.subheader("🏆 Multi-Method Valuation Suite")
    st.write("Evaluates Target Company Enterprise Value & Equity Value across Income (DCF), Market (Trading & Transaction Multiples), and Asset (Adjusted NAV) approaches.")
    
    st.info("⚠️ Professional Guardrail: Illustrative Valuation Summary for decision-support only. Not a formal valuation opinion under Sec 247 of Companies Act 2013 or IBBI guidelines.")
    
    val_table, val_summary = run_multi_method_valuation_summary(base_ev_input, wacc_pct=12.5)
    
    c_v1, c_v2, c_v3, c_v4 = st.columns(4)
    c_v1.metric("Weighted Enterprise Value", f"INR {val_summary['Weighted Average Enterprise Value']:.2f} Cr")
    c_v2.metric("Weighted Equity Value", f"INR {val_summary['Weighted Average Equity Value']:.2f} Cr")
    c_v3.metric("Total Shares", val_summary["Total Share Count"])
    c_v4.metric("Fair Value per Share", val_summary["Indicative Fair Value per Share"])
    
    st.markdown("---")
    st.markdown("#### 1. Multi-Method Valuation Summary Matrix")
    st.dataframe(val_table, use_container_width=True)
    
    # Valuation Comparison Bar Chart
    val_chart = val_table.set_index("Methodology")[["Enterprise Value (INR Cr)", "Indicative Equity Value (INR Cr)"]]
    st.bar_chart(val_chart)
    
    st.markdown("---")
    st.markdown("#### 2. Discounted Cash Flow (DCF FCFF) 5-Year Schedule")
    dcf_sch, dcf_sum = run_dcf_valuation(base_fcf=12.5, wacc_pct=12.5)
    st.dataframe(dcf_sch, use_container_width=True)
    st.write(f"**DCF Parameters**: WACC = {dcf_sum['WACC (%)']}%, Perpetual Terminal Growth Rate = {dcf_sum['Terminal Growth (%)']}%, Sum 5-Yr PV FCF = INR {dcf_sum['Sum PV 5-Yr FCF (Cr)']} Cr, PV Terminal Value = INR {dcf_sum['PV Terminal Value (Cr)']} Cr.")

# ----------------------------------------------------
# TAB 13: RISK CENTRE
# ----------------------------------------------------
with tabs[12]:
    st.subheader("⚠️ Explainable Risk Centre & 0–100 Scoring Model")
    
    risk_df, risk_summary = calculate_overall_risk_score()
    
    st.markdown(f"### Overall Risk Score: **{risk_summary['Overall Risk Score']} / 100** ({risk_summary['Risk Category']} RISK)")
    st.dataframe(risk_df, use_container_width=True)

# ----------------------------------------------------
# TAB 14: AI COPILOT (RAG CHAT)
# ----------------------------------------------------
with tabs[13]:
    st.subheader("💬 AI M&A Copilot — Transaction RAG Assistant")
    st.write("Ask natural language questions about the transaction data room. Every answer strictly includes source citations.")
    
    suggested_q = st.selectbox(
        "Suggested DD Questions:",
        [
            "Custom Question...",
            "What are the top five risks affecting valuation?",
            "What are the major Quality of Earnings (QoE) concerns?",
            "What tax and GST exposures have been identified?",
            "What are the working capital concerns and receivable ageing issues?",
            "Which customers create concentration risk?",
            "Identify potential related party transaction issues.",
            "What unusual journal entries require forensic investigation?"
        ]
    )
    
    if suggested_q != "Custom Question...":
        user_query = st.text_input("Your Question:", value=suggested_q)
    else:
        user_query = st.text_input("Your Question:", value="What are the top five risks?")
        
    if st.button("Ask AI Copilot", type="primary"):
        with st.spinner("Analyzing Data Room evidence and retrieving relevant chunks..."):
            res = st.session_state.rag_engine.query(user_query, api_key=openai_api_key)
            
            st.markdown(f"**Execution Mode**: `{res['mode']}`")
            st.markdown("### Answer:")
            st.markdown(res["answer"])
            
            st.markdown("---")
            st.markdown("#### Retrieved Source Evidence Chunks:")
            for ev in res["evidence"]:
                with st.expander(f"{ev['source_tag']} (Relevance Score: {ev['score']})"):
                    st.write(ev["text"])

# ----------------------------------------------------
# TAB 15: MANAGEMENT DD QUESTIONS
# ----------------------------------------------------
with tabs[14]:
    st.subheader("❓ AI Management DD Question Generator")
    st.write("Automatically converted analytical red flags into professional, evidence-based management due diligence questions.")
    
    mq_df = generate_management_questions()
    st.dataframe(mq_df, use_container_width=True)

# ----------------------------------------------------
# TAB 16: MULTI-AGENT REVIEW
# ----------------------------------------------------
with tabs[15]:
    st.subheader("🤖 Multi-Agent Architecture Review Panel")
    st.write("Specialist AI Agents conduct parallel audits across 9 domain verticals, synthesized by the Lead M&A Agent.")
    
    if st.button("Run Multi-Agent Audit Panel"):
        summary_text, agent_df = run_lead_agent_synthesis()
        st.markdown(summary_text)
        st.markdown("---")
        st.markdown("#### Specialist AI Agents Matrix Output")
        st.dataframe(agent_df, use_container_width=True)

# ----------------------------------------------------
# TAB 17: REVIEW & REPORTS
# ----------------------------------------------------
with tabs[16]:
    st.subheader("📋 Human-in-the-Loop Review & Professional Report Exporter")
    
    st.markdown("#### 1. CA Reviewer Audit Trail")
    st.info("Chartered Accountant feedback and review decisions for AI findings.")
    
    for idx, item in enumerate(st.session_state.review_trail):
        with st.expander(f"[{item['Finding ID']}] {item['Category']}: {item['AI Finding'][:60]}..."):
            st.write(f"**AI Recommendation**: {item['AI Recommendation']}")
            
            dec = st.radio(
                f"Reviewer Decision for {item['Finding ID']}",
                ["Pending Review", "Accept", "Reject", "Needs More Evidence", "Ask Management", "Escalate"],
                key=f"dec_{item['Finding ID']}"
            )
            comm = st.text_input(f"Reviewer Comment for {item['Finding ID']}", key=f"comm_{item['Finding ID']}")
            
            if st.button(f"Save Decision ({item['Finding ID']})", key=f"btn_{item['Finding ID']}"):
                update_review_decision(st.session_state.review_trail, item['Finding ID'], dec, comm)
                st.success(f"Updated decision for {item['Finding ID']}.")

    st.markdown("---")
    st.markdown("#### 2. Report Generation")
    
    r_col1, r_col2, r_col3 = st.columns(3)
    
    with r_col1:
        if st.button("Generate PDF Report", type="primary"):
            pdf_path = generate_pdf_report()
            with open(pdf_path, "rb") as f:
                st.download_button("Download PDF Report", f, file_name="MA_Copilot_Due_Diligence_Report.pdf", mime="application/pdf")
                
    with r_col2:
        if st.button("Generate 14-Sheet Excel Workbook"):
            excel_path = generate_excel_report()
            with open(excel_path, "rb") as f:
                st.download_button("Download Excel Report", f, file_name="MA_Copilot_Due_Diligence_Report.xlsx", mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")
                
    with r_col3:
        if st.button("Generate Formatted TXT Report"):
            txt_content = generate_txt_report(target_company, acquirer_company)
            st.download_button("Download TXT Report", txt_content, file_name="MA_Copilot_Due_Diligence_Report.txt", mime="text/plain")

    st.markdown("---")
    st.caption(DISCLAIMER_TEXT)
