"""
Human-in-the-Loop Review Trail Engine
Enables Chartered Accountants / Reviewers to evaluate, accept, reject, or escalate AI-identified due diligence findings.
Maintains a persistent session audit trail for professional compliance.
"""
import pandas as pd
from datetime import datetime

def init_review_trail():
    """
    Initializes standard AI findings for reviewer feedback.
    """
    findings = [
        {
            "Finding ID": "FIND-001",
            "Category": "Quality of Earnings",
            "AI Finding": "INR 3.80 Cr consultancy fee to promoter entity (KMP Consulting) lacks contract and proof of service.",
            "AI Recommendation": "Potential Add-back / EBITDA Normalization (Subject to CA Validation)",
            "Reviewer Decision": "Pending Review",
            "Reviewer Comment": "",
            "Timestamp": ""
        },
        {
            "Finding ID": "FIND-002",
            "Category": "Commercial Concentration",
            "AI Finding": "Top customer Apex Global Corp (37% revenue) contract expires in Dec 2025.",
            "AI Recommendation": "Require Contract Renewal as Condition Precedent (CP)",
            "Reviewer Decision": "Pending Review",
            "Reviewer Comment": "",
            "Timestamp": ""
        },
        {
            "Finding ID": "FIND-003",
            "Category": "GST & Indirect Tax",
            "AI Finding": "GSTR-3B turnover mismatch of INR 6.80 Cr & unmatched GSTR-2A ITC claim of INR 2.05 Cr.",
            "AI Recommendation": "Escalate to Tax Senior / Require 100% Tax Indemnity",
            "Reviewer Decision": "Pending Review",
            "Reviewer Comment": "",
            "Timestamp": ""
        },
        {
            "Finding ID": "FIND-004",
            "Category": "Working Capital",
            "AI Finding": "Receivables DSO surged to 102 days with INR 4.40 Cr overdue > 180 days.",
            "AI Recommendation": "Apply INR 10.80 Cr Working Capital Adjustment to Base EV",
            "Reviewer Decision": "Pending Review",
            "Reviewer Comment": "",
            "Timestamp": ""
        },
        {
            "Finding ID": "FIND-005",
            "Category": "Forensic Analytics",
            "AI Finding": "Manual post-closing JV-2025-901 crediting unbilled revenue by INR 55.0 Lakhs posted by SUPERADMIN.",
            "AI Recommendation": "Ask Management for customer acceptance certificate",
            "Reviewer Decision": "Pending Review",
            "Reviewer Comment": "",
            "Timestamp": ""
        }
    ]
    return findings

def update_review_decision(trail, finding_id, decision, comment=""):
    """
    Updates decision for a specific finding in the review audit trail.
    """
    for item in trail:
        if item["Finding ID"] == finding_id:
            item["Reviewer Decision"] = decision
            item["Reviewer Comment"] = comment
            item["Timestamp"] = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            break
    return trail
