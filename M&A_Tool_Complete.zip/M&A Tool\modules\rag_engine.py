"""
RAG Engine (Retrieval-Augmented Generation)
Supports hybrid offline mode (TF-IDF + Cosine Similarity) and online mode (OpenAI API / Vector DB).
Maintains strict source attribution and anti-hallucination guardrails.
"""
import os
import requests
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

class RAGEngine:
    def __init__(self, chunks):
        self.chunks = chunks
        self.vectorizer = None
        self.tfidf_matrix = None
        self._build_offline_index()

    def _build_offline_index(self):
        if not self.chunks:
            return
        corpus = [c["text"] for c in self.chunks]
        self.vectorizer = TfidfVectorizer(stop_words="english")
        self.tfidf_matrix = self.vectorizer.fit_transform(corpus)

    def retrieve(self, query, top_k=4):
        if not self.chunks or self.vectorizer is None:
            return []
        
        query_vec = self.vectorizer.transform([query])
        similarities = cosine_similarity(query_vec, self.tfidf_matrix).flatten()
        top_indices = similarities.argsort()[::-1][:top_k]
        
        results = []
        for idx in top_indices:
            score = float(similarities[idx])
            if score > 0.05:  # Relevance threshold
                chunk = self.chunks[idx].copy()
                chunk["score"] = round(score, 4)
                results.append(chunk)
        return results

    def query(self, query_text, api_key=None, model="gpt-4o-mini"):
        retrieved_chunks = self.retrieve(query_text, top_k=4)
        
        if not retrieved_chunks:
            return {
                "answer": "Insufficient evidence available in the Data Room.",
                "evidence": [],
                "sources": [],
                "mode": "Offline Analytical"
            }
        
        context_str = ""
        sources = []
        for chunk in retrieved_chunks:
            tag = chunk["source_tag"]
            context_str += f"{tag}:\n{chunk['text']}\n\n"
            sources.append(tag)
        
        # Check if OpenAI API Key is provided for online mode
        if api_key and api_key.strip():
            try:
                headers = {
                    "Authorization": f"Bearer {api_key}",
                    "Content-Type": "application/json"
                }
                system_prompt = (
                    "You are a Senior M&A Due Diligence Specialist and Chartered Accountant. "
                    "Answer the user query strictly using only the supplied context evidence. "
                    "Always cite the exact source tag [Source: filename | location] for every key factual claim. "
                    "If the evidence is insufficient to answer the question, state: "
                    "'Insufficient evidence available in the Data Room.'"
                )
                user_prompt = f"CONTEXT EVIDENCE:\n{context_str}\n\nUSER QUESTION: {query_text}"
                
                payload = {
                    "model": model,
                    "messages": [
                        {"role": "system", "content": system_prompt},
                        {"role": "user", "content": user_prompt}
                    ],
                    "temperature": 0.2
                }
                
                resp = requests.post("https://api.openai.com/v1/chat/completions", json=payload, headers=headers, timeout=25)
                if resp.status_code == 200:
                    answer = resp.json()["choices"][0]["message"]["content"]
                    return {
                        "answer": answer,
                        "evidence": retrieved_chunks,
                        "sources": list(set(sources)),
                        "mode": "OpenAI LLM (Online RAG)"
                    }
            except Exception as e:
                pass  # Fallback to offline analytical synthesis

        # Offline Analytical Synthesis
        synthesis = f"**Analytical RAG Answer (Offline Mode)**:\n\nBased on {len(retrieved_chunks)} retrieved data room documents:\n\n"
        for chunk in retrieved_chunks:
            synthesis += f"- **{chunk['source_tag']}**: {chunk['text'][:250]}...\n\n"
        
        synthesis += "\n*Note: Running in offline analytical mode. Provide an OpenAI API Key in the sidebar for generative LLM responses.*"
        
        return {
            "answer": synthesis,
            "evidence": retrieved_chunks,
            "sources": list(set(sources)),
            "mode": "TF-IDF Offline Retriever"
        }
