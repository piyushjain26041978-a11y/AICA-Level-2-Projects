# ICAI AICA LEVEL-2 PRESENTATION DECK SCRIPT

**Title**: M&A Copilot — AI-Powered Due Diligence & Deal Intelligence Platform  
**Presenter**: Chartered Accountant / AI Solution Architect  

---

### SLIDE 1: Title Slide
- **Title**: M&A Copilot — AI-Powered Due Diligence & Deal Intelligence
- **Tagline**: From Data Room to Deal Intelligence
- **Subtitle**: ICAI AICA Level-2 Practical Capstone Demonstration

---

### SLIDE 2: Business Context & Problem Statement
- **M&A Complexity**: Transaction data rooms contain hundreds of unstructured PDFs, Excel workbooks, and tax filings.
- **Pain Point**: CAs spend 70% of time extracting data and only 30% analyzing deal risks.
- **Solution**: M&A Copilot AI automates first-level evidence extraction, QoE adjustments, GST reconciliations, forensic exception flagging, and deal valuation bridge calculations.

---

### SLIDE 3: AI & Hybrid RAG Architecture
- **Offline & Online Dual Execution**: Works 100% offline using TF-IDF vector retrieval and analytical engines; integrates OpenAI API when connected.
- **Source Citation Enforcement**: Every output contains `[Source: filename | Page/Sheet]`.
- **Anti-Hallucination**: Answers strictly from evidence or flags "Insufficient evidence".

---

### SLIDE 4: Core Analytical Engines
1. **Financial Engine**: DSO, DIO, DPO, CFO/EBITDA conversion, debt leverage.
2. **QoE Engine**: Reported EBITDA -> Potential Adjustments -> Adjusted EBITDA.
3. **GST & Tax Engine**: Books vs GSTR-3B / 2A turnover & ITC reconciliation.
4. **Forensic Journal Engine**: Round numbers, weekend entries, post-closing manual JVs.
5. **Commercial Engine**: HHI index, Top 1/3/5 concentration ratios.

---

### SLIDE 5: Deal Value Bridge & Scenario Lab
- **Enterprise Value to Equity Value**: $EV - Debt + Cash \pm WC_{adj} - Tax_{exp} - Debt_{like} = Equity Value$.
- **Scenario Lab**: Interactive stress testing under Base, Downside, and Severe Downside cases.

---

### SLIDE 6: Human-in-the-Loop & Governance
- Professional judgment remains with the CA.
- Interactive audit trail for CA review (Accept/Reject/Escalate).
- Professional disclaimers embedded in all generated PDF, Excel, and TXT reports.

---

### SLIDE 7: Demonstration & Conclusion
- Live demonstration of Streamlit application.
- Comprehensive 14-sheet Excel export and ReportLab PDF generation.
