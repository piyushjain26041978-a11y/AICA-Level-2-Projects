@echo off
title M&A Copilot AI - Launcher
echo ===================================================
echo   M^&A Copilot — AI-Powered Due Diligence Platform
echo   ICAI AICA Level-2 Demonstration Environment
echo ===================================================
echo.
echo Installing / Verifying dependencies...
pip install -r requirements.txt
echo.
echo Launching Streamlit Application...
streamlit run app.py
pause
