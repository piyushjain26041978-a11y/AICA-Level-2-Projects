# M&A COPILOT AI — USER MANUAL

## 1. Installation & Environment Setup
1. Ensure Python 3.10 or higher is installed on your Windows system.
2. Extract the project files to your preferred workspace directory.
3. Launch the application by double-clicking `run_app.bat`.

## 2. Platform Navigation & Features

### Sidebar Setup
- **Target Company & Acquirer**: Input entity names.
- **Base EV & WC Peg**: Set negotiated Enterprise Value baseline and Working Capital Peg.
- **AI Mode**: Select between Offline Analytical (TF-IDF) or Online OpenAI LLM (requires API key).

### Dashboard & Analytics Tabs
1. **Dashboard**: High-level KPI summary cards, trajectory charts, overall 0-100 deal risk score.
2. **Data Room**: Upload transaction documents or inspect pre-indexed sample files.
3. **Financials**: P&L, Balance Sheet, Cash Flow, CFO conversion, and ratio trends.
4. **Quality of Earnings**: Evaluate Reported vs Adjusted EBITDA normalization bridge.
5. **Working Capital**: Debtor/Creditor ageing, slow-moving inventory, NWC Peg adjustment.
6. **GST & Tax DD**: GST turnover and ITC reconciliation between Books and Returns.
7. **Commercial**: Customer and Supplier concentration analytics (HHI index).
8. **Related Parties**: Entity relationship matching, common directors, arm's length evaluation.
9. **Forensic Analytics**: Flagged anomaly journal entry population.
10. **Deal Bridge & Scenarios**: EV to Equity Value Bridge + dynamic sensitivity sliders.
11. **Risk Centre**: Explainable 0-100 deal risk score breakdown across 15 categories.
12. **AI Copilot**: RAG Q&A interface with source citations.
13. **DD Questions**: Auto-generated evidence-based management questions.
14. **Multi-Agent Review**: Execute 9 specialist agents and Lead Agent synthesis.
15. **Review & Reports**: Human-in-the-Loop review audit trail and PDF/Excel/TXT report exports.

## 3. Professional Control & Safety Rule
All outputs produced by M&A Copilot AI are decision-support indicators. Chartered Accountants must validate all key findings against original data room documents before issuing final advice.
