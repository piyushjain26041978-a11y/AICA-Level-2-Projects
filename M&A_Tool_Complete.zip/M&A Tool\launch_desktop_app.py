"""
Native Desktop Launcher Script for M&A Copilot AI
Launches Streamlit backend server and opens web app in standalone browser window.
"""
import os
import sys
import time
import webbrowser
import subprocess

def main():
    print("===================================================")
    print("  M&A Copilot AI — Desktop Platform Launcher")
    print("  ICAI AICA Level-2 Production Environment")
    print("===================================================")
    
    app_dir = os.path.dirname(os.path.abspath(__file__))
    app_path = os.path.join(app_dir, "app.py")
    
    print("Starting M&A Copilot AI Server...")
    cmd = [sys.executable, "-m", "streamlit", "run", app_path, "--server.headless", "true", "--server.port", "8501"]
    
    proc = subprocess.Popen(cmd, cwd=app_dir)
    time.sleep(3)
    
    url = "http://localhost:8501"
    print(f"Opening desktop browser at {url}...")
    webbrowser.open(url)
    
    try:
        proc.wait()
    except KeyboardInterrupt:
        proc.terminate()

if __name__ == "__main__":
    main()
