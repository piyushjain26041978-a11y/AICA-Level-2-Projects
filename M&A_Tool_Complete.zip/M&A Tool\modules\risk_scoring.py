"""
Risk Scoring & Risk Centre Engine
Computes an explainable 0–100 Deal Risk Score across 15 risk dimensions.
Follows CA guardrail: "Never present the score as an audit conclusion."
"""
import pandas as pd

def calculate_overall_risk_score():
    """
    Returns 15 risk categories with weightings, scores, risk drivers, and recommended actions.
    """
    categories = [
        {
            "Category": "Financial",
            "Weight": 0.08,
            "Score (0-100)": 75,
            "Risk Level": "HIGH",
            "Key Risk Drivers": "EBITDA margin compression (-270 bps) and severe CFO conversion drop (73% -> 30%).",
            "Evidence": "Financials.xlsx (P&L & Cash Flow)",
            "Recommended Action": "Perform month-on-month revenue & cost breakdown for FY25."
        },
        {
            "Category": "Quality of Earnings (QoE)",
            "Weight": 0.10,
            "Score (0-100)": 82,
            "Risk Level": "CRITICAL",
            "Key Risk Drivers": "INR 9.05 Cr of potential EBITDA adjustments (Asset sale gain, unverified fees, promoter personal expenses).",
            "Evidence": "QoE Engine & Journal_Entries.xlsx",
            "Recommended Action": "Normalize EBITDA and adjust valuation multiple accordingly."
        },
        {
            "Category": "Tax",
            "Weight": 0.08,
            "Score (0-100)": 65,
            "Risk Level": "HIGH",
            "Key Risk Drivers": "INR 7.75 Cr in tax disputes (Sec 80IA disallowance & Sec 68 share premium addition).",
            "Evidence": "Tax_Data.xlsx & Demo_Legal_Memo.txt",
            "Recommended Action": "Obtain tax indemnity clause in Share Purchase Agreement (SPA)."
        },
        {
            "Category": "GST",
            "Weight": 0.08,
            "Score (0-100)": 70,
            "Risk Level": "HIGH",
            "Key Risk Drivers": "INR 6.80 Cr turnover mismatch & INR 2.05 Cr unmatched GSTR-2A ITC claim.",
            "Evidence": "GST_Books.xlsx vs GST_Return.xlsx",
            "Recommended Action": "Commission comprehensive 100% GST audit before deal closing."
        },
        {
            "Category": "Working Capital",
            "Weight": 0.08,
            "Score (0-100)": 78,
            "Risk Level": "HIGH",
            "Key Risk Drivers": "Receivables DSO spiked to 102 days (+34 days); INR 4.4 Cr overdue > 180 days.",
            "Evidence": "Debtor_Ageing.xlsx & BalanceSheet",
            "Recommended Action": "Incorporate Working Capital Peg Adjustment ($WC_{actual} - WC_{peg}$) in Equity Bridge."
        },
        {
            "Category": "Net Debt",
            "Weight": 0.06,
            "Score (0-100)": 60,
            "Risk Level": "HIGH",
            "Key Risk Drivers": "Net Debt increased +68% in FY25 to INR 32.0 Cr.",
            "Evidence": "Financials.xlsx (Balance Sheet)",
            "Recommended Action": "Deduct full Gross Debt and verify off-balance sheet guarantees."
        },
        {
            "Category": "Customer Concentration",
            "Weight": 0.08,
            "Score (0-100)": 88,
            "Risk Level": "CRITICAL",
            "Key Risk Drivers": "Top 1 Customer accounts for 37.0% of sales; Top 3 account for 72.0% (HHI 2182).",
            "Evidence": "Customer_Sales.xlsx",
            "Recommended Action": "Make contract renewal of Apex Global Corp a Condition Precedent (CP)."
        },
        {
            "Category": "Supplier Concentration",
            "Weight": 0.06,
            "Score (0-100)": 72,
            "Risk Level": "HIGH",
            "Key Risk Drivers": "Sole supplier for resin raw material (46.7% purchase share) with no price lock clause.",
            "Evidence": "Vendor_Data.xlsx",
            "Recommended Action": "Negotiate dual-sourcing vendor contracts post-acquisition."
        },
        {
            "Category": "Related Party",
            "Weight": 0.08,
            "Score (0-100)": 85,
            "Risk Level": "CRITICAL",
            "Key Risk Drivers": "INR 16.10 Cr (10.9% revenue) in transactions with unverified service scopes and above-market rents.",
            "Evidence": "Related_Party_Master.xlsx & Demo_Legal_Memo.txt",
            "Recommended Action": "Require promoter exit/termination of related party consulting agreements."
        },
        {
            "Category": "Forensic",
            "Weight": 0.06,
            "Score (0-100)": 68,
            "Risk Level": "HIGH",
            "Key Risk Drivers": "8 exception journal entries flagged (INR 3.25 Cr round numbers & post-closing manual JVs).",
            "Evidence": "Journal_Entries.xlsx",
            "Recommended Action": "Perform forensic audit on manual JV vouchers posted by SUPERADMIN."
        },
        {
            "Category": "Legal",
            "Weight": 0.05,
            "Score (0-100)": 58,
            "Risk Level": "MODERATE",
            "Key Risk Drivers": "High Court environmental show-cause notice (INR 3.5 Cr penalty potential).",
            "Evidence": "Demo_Legal_Memo.txt",
            "Recommended Action": "Require environmental escrow fund deposit."
        },
        {
            "Category": "Commercial",
            "Weight": 0.04,
            "Score (0-100)": 62,
            "Risk Level": "HIGH",
            "Key Risk Drivers": "Disputed invoices with Delta Tech (high churn risk).",
            "Evidence": "Customer_Sales.xlsx",
            "Recommended Action": "Conduct customer reference calls."
        },
        {
            "Category": "ESG/EHS",
            "Weight": 0.02,
            "Score (0-100)": 45,
            "Risk Level": "MODERATE",
            "Key Risk Drivers": "Tarapur Unit-2 pollution board notice.",
            "Evidence": "Demo_Legal_Memo.txt",
            "Recommended Action": "Commission EHS compliance audit."
        },
        {
            "Category": "HR",
            "Weight": 0.02,
            "Score (0-100)": 50,
            "Risk Level": "MODERATE",
            "Key Risk Drivers": "Unfunded gratuity (INR 1.85 Cr) & missing non-competes for 2 Senior VPs.",
            "Evidence": "Demo_Legal_Memo.txt",
            "Recommended Action": "Execute non-compete agreements prior to closing."
        },
        {
            "Category": "Valuation Sensitivity",
            "Weight": 0.03,
            "Score (0-100)": 74,
            "Risk Level": "HIGH",
            "Key Risk Drivers": "High Equity Value erosion (-38%) under downside stress scenario.",
            "Evidence": "Scenario Lab Engine",
            "Recommended Action": "Structure deal with earn-outs linked to EBITDA performance."
        }
    ]
    
    df = pd.DataFrame(categories)
    
    # Calculate Weighted Overall Score
    weighted_score = sum(row["Weight"] * row["Score (0-100)"] for row in categories)
    overall_score = round(weighted_score, 1)  # ~72.8 (HIGH RISK)
    
    if overall_score >= 80:
        overall_category = "CRITICAL"
    elif overall_score >= 60:
        overall_category = "HIGH"
    elif overall_score >= 40:
        overall_category = "MODERATE"
    else:
        overall_category = "LOW"
        
    summary = {
        "Overall Risk Score": overall_score,
        "Risk Category": overall_category,
        "Critical Categories Count": len(df[df["Risk Level"] == "CRITICAL"]),
        "High Categories Count": len(df[df["Risk Level"] == "HIGH"]),
        "Moderate Categories Count": len(df[df["Risk Level"] == "MODERATE"])
    }
    
    return df, summary
