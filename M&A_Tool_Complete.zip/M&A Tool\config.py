"""
M&A Copilot — Configuration & Application Settings
Sober Executive Light Theme with Smooth Scrolling UI
"""
import os

# Platform Metadata
APP_TITLE = "M&A Copilot — AI-Powered Due Diligence & Deal Intelligence"
APP_TAGLINE = "From Data Room to Deal Intelligence"
APP_VERSION = "v4.0 (ICAI AICA Level-2 Production Grade)"
AUTHOR = "Chartered Accountant / M&A Advisory Specialist"

# Professional Disclaimer Notice
DISCLAIMER_TEXT = (
    "DISCLAIMER: This software is an AI-assisted professional decision-support system designed to assist "
    "Chartered Accountants, financial analysts, and M&A transaction teams in performing due diligence. "
    "It is NOT a replacement for professional audit, legal, tax, or valuation advice. All AI-generated outputs, "
    "risk indicators, Quality of Earnings adjustments, and tax exposure estimates are indicative and subject to "
    "mandatory validation against source documents and professional judgment."
)

# Color Palette (Sober Executive Light Corporate Theme)
COLORS = {
    "primary": "#1E3A8A",      # Deep Executive Navy
    "secondary": "#0284C7",    # Slate Blue
    "accent": "#0D9488",       # Sober Teal
    "background": "#F8FAFC",   # Soft Crisp Off-White
    "card_bg": "#FFFFFF",      # Pure White Card
    "text_main": "#0F172A",    # Dark Slate Text (High Contrast)
    "text_muted": "#475569",   # Medium Slate Gray
    "success": "#059669",      # Soft Emerald Green
    "warning": "#D97706",      # Amber Gold
    "danger": "#DC2626",       # Crimson Red
    "info": "#2563EB",         # Corporate Blue
    "border": "#E2E8F0"        # Soft Gray Border
}

# Streamlit Custom CSS (Silky Smooth Scrolling & Responsive UI)
CUSTOM_CSS = """
<style>
    @import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap');
    
    html {
        scroll-behavior: smooth;
    }
    
    html, body, [class*="css"] {
        font-family: 'Inter', sans-serif;
    }
    
    /* Custom Scrollbar Styling */
    ::-webkit-scrollbar {
        width: 8px;
        height: 8px;
    }
    ::-webkit-scrollbar-track {
        background: #F1F5F9;
        border-radius: 4px;
    }
    ::-webkit-scrollbar-thumb {
        background: #94A3B8;
        border-radius: 4px;
    }
    ::-webkit-scrollbar-thumb:hover {
        background: #64748B;
    }
    
    /* Main Background & Text */
    .stApp {
        background-color: #F8FAFC;
        color: #0F172A;
    }
    
    /* Sidebar Styling */
    [data-testid="stSidebar"] {
        background-color: #F1F5F9;
        border-right: 1px solid #E2E8F0;
    }
    
    [data-testid="stSidebar"] h1, [data-testid="stSidebar"] h2, [data-testid="stSidebar"] h3, [data-testid="stSidebar"] p {
        color: #0F172A !important;
    }
    
    /* Responsive Scrollable Navigation Tab Bar */
    div[data-baseweb="tab-list"] {
        gap: 6px;
        overflow-x: auto !important;
        flex-wrap: nowrap !important;
        padding-bottom: 8px !important;
        border-bottom: 2px solid #E2E8F0;
    }
    
    button[data-baseweb="tab"] {
        padding: 10px 18px !important;
        font-weight: 600 !important;
        font-size: 0.88rem !important;
        white-space: nowrap !important;
        border-radius: 6px 6px 0 0 !important;
        color: #475569 !important;
        transition: all 0.2s ease-in-out;
    }
    
    button[data-baseweb="tab"]:hover {
        color: #1E3A8A !important;
        background-color: #EFF6FF !important;
    }
    
    button[aria-selected="true"] {
        color: #1E3A8A !important;
        border-bottom: 3px solid #1E3A8A !important;
        background-color: #FFFFFF !important;
    }
    
    /* Header Styling */
    h1, h2, h3, h4 {
        color: #0F172A !important;
        font-weight: 600;
    }
    
    /* Card Container Styling */
    .ma-card {
        background-color: #FFFFFF;
        border: 1px solid #E2E8F0;
        border-radius: 10px;
        padding: 20px;
        margin-bottom: 15px;
        box-shadow: 0 2px 5px rgba(0, 0, 0, 0.04);
    }
    
    /* KPI Card Styling */
    .kpi-card {
        background: #FFFFFF;
        border: 1px solid #E2E8F0;
        border-left: 5px solid #1E3A8A;
        border-radius: 10px;
        padding: 18px;
        text-align: left;
        box-shadow: 0 2px 6px rgba(0, 0, 0, 0.05);
    }
    
    .kpi-title {
        color: #64748B;
        font-size: 0.8rem;
        font-weight: 600;
        text-transform: uppercase;
        letter-spacing: 0.06em;
    }
    
    .kpi-value {
        color: #0F172A;
        font-size: 1.6rem;
        font-weight: 700;
        margin-top: 5px;
        margin-bottom: 5px;
    }
    
    .kpi-subtext {
        color: #059669;
        font-size: 0.82rem;
        font-weight: 600;
    }
    
    /* Risk Badges */
    .badge-low {
        background-color: #D1FAE5;
        color: #065F46;
        padding: 4px 12px;
        border-radius: 12px;
        font-size: 0.78rem;
        font-weight: 600;
    }
    
    .badge-moderate {
        background-color: #FEF3C7;
        color: #92400E;
        padding: 4px 12px;
        border-radius: 12px;
        font-size: 0.78rem;
        font-weight: 600;
    }
    
    .badge-high {
        background-color: #FEE2E2;
        color: #991B1B;
        padding: 4px 12px;
        border-radius: 12px;
        font-size: 0.78rem;
        font-weight: 600;
    }
    
    .badge-critical {
        background-color: #7F1D1D;
        color: #FFFFFF;
        padding: 4px 12px;
        border-radius: 12px;
        font-size: 0.78rem;
        font-weight: 600;
    }
    
    /* Source Tag Styling */
    .source-tag {
        background-color: #EFF6FF;
        color: #1E40AF;
        border: 1px solid #BFDBFE;
        padding: 3px 10px;
        border-radius: 6px;
        font-size: 0.8rem;
        font-weight: 600;
        font-family: monospace;
    }
    
    /* Upload Box & Helper Callout */
    .upload-callout {
        background-color: #F0F9FF;
        border-left: 4px solid #0284C7;
        padding: 15px;
        border-radius: 6px;
        margin-bottom: 20px;
    }
</style>
"""

# Risk Categories
RISK_CATEGORIES = [
    "Financial",
    "QoE",
    "Tax",
    "GST",
    "Working Capital",
    "Net Debt",
    "Customer Concentration",
    "Supplier Concentration",
    "Related Party",
    "Forensic",
    "Legal",
    "Commercial",
    "ESG/EHS",
    "HR",
    "Valuation Sensitivity"
]

# Risk Thresholds
RISK_LEVELS = {
    "LOW": (0, 39, "#059669"),
    "MODERATE": (40, 59, "#D97706"),
    "HIGH": (60, 79, "#DC2626"),
    "CRITICAL": (80, 100, "#7F1D1D")
}
