"""
Due Diligence Master Checklist & Verification Tracker Module
Provides an interactive CA Due Diligence Checklist with checkboxes, completion progress tracking, and sign-offs.
"""
import pandas as pd
from datetime import datetime

def init_dd_checklist():
    """
    Initializes the master due diligence checklist across 10 DD categories.
    """
    checklist_items = [
        # 1. Financial DD
        {
            "Item ID": "DD-FIN-01",
            "Category": "Financial DD",
            "Task Description": "Reconcile audited P&L and Balance Sheet figures against trial balance for FY23, FY24, FY25.",
            "Mandatory Document": "Financials.xlsx (P&L & BS)",
            "Status": "Completed",
            "Assigned CA": "Piyush Jain, CA",
            "Sign-off Date": "2025-03-14",
            "Notes": "Verified against signed audited financial statements."
        },
        {
            "Item ID": "DD-FIN-02",
            "Category": "Financial DD",
            "Task Description": "Analyze Cash Flow conversion ratio (CFO / EBITDA %) and evaluate cause for CFO drop in FY25.",
            "Mandatory Document": "Financials.xlsx (CashFlow)",
            "Status": "Completed",
            "Assigned CA": "Piyush Jain, CA",
            "Sign-off Date": "2025-03-14",
            "Notes": "CFO dropped to 30% due to receivables surge (+44% YoY)."
        },
        # 2. QoE DD
        {
            "Item ID": "DD-QOE-01",
            "Category": "Quality of Earnings",
            "Task Description": "Evaluate non-operating income (Asset sale gains & subsidies) included in Reported EBITDA.",
            "Mandatory Document": "P&L Note 14 & Data Room",
            "Status": "Completed",
            "Assigned CA": "Piyush Jain, CA",
            "Sign-off Date": "2025-03-14",
            "Notes": "INR 4.20 Cr one-time gain deducted from Reported EBITDA."
        },
        {
            "Item ID": "DD-QOE-02",
            "Category": "Quality of Earnings",
            "Task Description": "Verify management consultancy advisory fees paid to promoter entity KMP Consulting.",
            "Mandatory Document": "Journal_Entries.xlsx (JV-2025-902)",
            "Status": "Pending Management Reply",
            "Assigned CA": "Piyush Jain, CA",
            "Sign-off Date": "",
            "Notes": "Awaiting service agreement timesheets & arm's length study."
        },
        # 3. Working Capital DD
        {
            "Item ID": "DD-WC-01",
            "Category": "Working Capital",
            "Task Description": "Conduct Trade Receivables Ageing Audit & identify overdue balances > 180 days.",
            "Mandatory Document": "Debtor_Ageing.xlsx",
            "Status": "Completed",
            "Assigned CA": "Senior Analyst",
            "Sign-off Date": "2025-03-14",
            "Notes": "INR 4.40 Cr overdue > 180 days flagged as high credit risk."
        },
        {
            "Item ID": "DD-WC-02",
            "Category": "Working Capital",
            "Task Description": "Calculate Working Capital Peg Adjustment ($WC_{actual} - WC_{peg}$) for Equity Bridge.",
            "Mandatory Document": "BalanceSheet & Peg Calc",
            "Status": "Completed",
            "Assigned CA": "Piyush Jain, CA",
            "Sign-off Date": "2025-03-15",
            "Notes": "INR 10.80 Cr Working Capital Adjustment deducted from Base EV."
        },
        # 4. GST & Tax DD
        {
            "Item ID": "DD-TAX-01",
            "Category": "GST & Tax DD",
            "Task Description": "Reconcile turnover and tax liability between Books of Accounts and GSTR-3B filings.",
            "Mandatory Document": "GST_Books.xlsx vs GST_Return.xlsx",
            "Status": "Completed",
            "Assigned CA": "Tax Manager",
            "Sign-off Date": "2025-03-15",
            "Notes": "INR 6.80 Cr turnover mismatch & INR 1.22 Cr tax shortfall identified."
        },
        {
            "Item ID": "DD-TAX-02",
            "Category": "GST & Tax DD",
            "Task Description": "Reconcile Input Tax Credit (ITC) claimed in GSTR-3B against GSTR-2A auto-populated data.",
            "Mandatory Document": "GST_Return.xlsx (GSTR-2A)",
            "Status": "Completed",
            "Assigned CA": "Tax Manager",
            "Sign-off Date": "2025-03-15",
            "Notes": "INR 2.05 Cr unmatched ITC flagged for potential tax demand."
        },
        {
            "Item ID": "DD-TAX-03",
            "Category": "GST & Tax DD",
            "Task Description": "Review status of pending ITAT appeal for Sec 80IA disallowance & Transfer Pricing royalty.",
            "Mandatory Document": "Tax_Data.xlsx (AY 2021-22)",
            "Status": "In Progress",
            "Assigned CA": "Legal Counsel",
            "Sign-off Date": "",
            "Notes": "Written opinion requested from Senior Tax Counsel."
        },
        # 5. Related Party DD
        {
            "Item ID": "DD-RP-01",
            "Category": "Related Parties",
            "Task Description": "Identify all related party transactions with directors, KMPs, and promoter enterprises.",
            "Mandatory Document": "Related_Party_Master.xlsx",
            "Status": "Completed",
            "Assigned CA": "Piyush Jain, CA",
            "Sign-off Date": "2025-03-15",
            "Notes": "INR 16.10 Cr total RP volume (10.9% of sales) evaluated."
        },
        # 6. Forensic Analytics
        {
            "Item ID": "DD-FOR-01",
            "Category": "Forensic Analytics",
            "Task Description": "Scan general ledger population for manual year-end post-closing JVs posted by SUPERADMIN.",
            "Mandatory Document": "Journal_Entries.xlsx",
            "Status": "Completed",
            "Assigned CA": "Forensic Auditor",
            "Sign-off Date": "2025-03-15",
            "Notes": "JV-2025-901 (INR 55.0 Lakhs unbilled revenue) flagged for verification."
        },
        # 7. Commercial DD
        {
            "Item ID": "DD-COM-01",
            "Category": "Commercial DD",
            "Task Description": "Evaluate Top 1, Top 3, and Top 5 customer concentration ratios and contract expiration dates.",
            "Mandatory Document": "Customer_Sales.xlsx",
            "Status": "Completed",
            "Assigned CA": "Commercial Lead",
            "Sign-off Date": "2025-03-15",
            "Notes": "Apex Global Corp (37% sales) contract expires Dec 2025. CP required."
        },
        # 8. Legal & HR
        {
            "Item ID": "DD-LEG-01",
            "Category": "Legal & HR",
            "Task Description": "Review environmental show-cause notice for Tarapur Unit-2 plant.",
            "Mandatory Document": "Demo_Legal_Memo.txt | Sec 1",
            "Status": "In Progress",
            "Assigned CA": "Legal Counsel",
            "Sign-off Date": "",
            "Notes": "Environmental compliance audit commissioned."
        },
        {
            "Item ID": "DD-HR-01",
            "Category": "Legal & HR",
            "Task Description": "Verify actuarial valuation for gratuity liability under AS-15 / IND AS 19.",
            "Mandatory Document": "Demo_Legal_Memo.txt | Sec 4",
            "Status": "Pending Management Reply",
            "Assigned CA": "HR Lead",
            "Sign-off Date": "",
            "Notes": "Unfunded gratuity estimated at INR 1.85 Cr."
        }
    ]
    return checklist_items

def update_checklist_item(checklist, item_id, new_status, notes="", ca_name=""):
    """
    Updates the completion status and notes for a checklist item.
    """
    for item in checklist:
        if item["Item ID"] == item_id:
            item["Status"] = new_status
            if notes:
                item["Notes"] = notes
            if ca_name:
                item["Assigned CA"] = ca_name
            if new_status == "Completed":
                item["Sign-off Date"] = datetime.now().strftime("%Y-%m-%d")
            break
    return checklist

def calculate_checklist_progress(checklist):
    """
    Calculates progress metrics for the DD checklist.
    """
    total = len(checklist)
    completed = len([i for i in checklist if i["Status"] == "Completed"])
    in_progress = len([i for i in checklist if i["Status"] == "In Progress"])
    pending = len([i for i in checklist if "Pending" in i["Status"]])
    
    pct = round((completed / total) * 100, 1) if total > 0 else 0.0
    
    return {
        "Total Tasks": total,
        "Completed": completed,
        "In Progress": in_progress,
        "Pending": pending,
        "Completion Percentage": pct
    }
