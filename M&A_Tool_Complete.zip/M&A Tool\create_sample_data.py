import os
import pandas as pd
import numpy as np

os.makedirs("sample_data", exist_ok=True)

# 1. Financials.xlsx
with pd.ExcelWriter("sample_data/financials.xlsx", engine="openpyxl") as writer:
    pnl_df = pd.DataFrame({
        "Line Item": [
            "Revenue from Operations", "Other Income", "Total Income",
            "Cost of Materials Consumed", "Employee Benefits Expense", "Other Operating Expenses",
            "Reported EBITDA", "Depreciation & Amortisation", "EBIT", "Finance Costs",
            "Profit Before Tax (PBT)", "Tax Expense", "Profit After Tax (PAT)"
        ],
        "FY23 (INR Cr)": [120.5, 2.1, 122.6, 65.0, 18.2, 14.3, 25.1, 4.2, 20.9, 3.5, 17.4, 4.3, 13.1],
        "FY24 (INR Cr)": [138.2, 3.5, 141.7, 74.8, 21.0, 17.9, 28.0, 4.8, 23.2, 3.8, 19.4, 4.8, 14.6],
        "FY25 (INR Cr)": [148.0, 8.4, 156.4, 82.5, 25.4, 22.5, 26.0, 5.5, 20.5, 4.2, 16.3, 4.1, 12.2]
    })
    pnl_df.to_excel(writer, sheet_name="P&L", index=False)

    bs_df = pd.DataFrame({
        "Balance Sheet Line": [
            "Property, Plant & Equipment", "Non-Current Assets",
            "Inventories", "Trade Receivables", "Cash & Cash Equivalents", "Other Current Assets",
            "Total Assets",
            "Equity Share Capital", "Reserves & Surplus", "Total Equity",
            "Long-Term Borrowings", "Short-Term Borrowings", "Gross Debt",
            "Trade Payables", "Other Current Liabilities", "Total Liabilities"
        ],
        "FY23 (INR Cr)": [35.0, 42.0, 15.2, 22.4, 5.1, 4.3, 89.0, 10.0, 32.5, 42.5, 12.0, 8.5, 20.5, 18.2, 7.8, 89.0],
        "FY24 (INR Cr)": [38.5, 46.2, 18.5, 28.6, 6.2, 5.1, 104.6, 10.0, 41.1, 51.1, 15.0, 10.2, 25.2, 20.5, 7.8, 104.6],
        "FY25 (INR Cr)": [42.0, 51.0, 24.8, 41.2, 4.5, 6.8, 128.3, 10.0, 48.3, 58.3, 22.0, 14.5, 36.5, 24.1, 9.4, 128.3]
    })
    bs_df.to_excel(writer, sheet_name="BalanceSheet", index=False)

    cf_df = pd.DataFrame({
        "Cash Flow Activity": [
            "Cash Flow from Operations (CFO)",
            "Capital Expenditure (Capex)",
            "Cash Flow from Investing (CFI)",
            "Cash Flow from Financing (CFF)",
            "Net Increase/(Decrease) in Cash"
        ],
        "FY23 (INR Cr)": [18.4, -6.5, -6.0, -10.2, 2.2],
        "FY24 (INR Cr)": [14.2, -8.0, -7.5, -5.6, 1.1],
        "FY25 (INR Cr)": [7.8, -9.5, -9.0, -0.5, -1.7]
    })
    cf_df.to_excel(writer, sheet_name="CashFlow", index=False)

# 2. customer_sales.xlsx
with pd.ExcelWriter("sample_data/customer_sales.xlsx", engine="openpyxl") as writer:
    cust_df = pd.DataFrame({
        "Customer Name": ["Apex Global Corp", "Zenith Logistics", "Nexus Retail Ltd", "Vanguard Systems", "Orion Enterprises", "Delta Tech", "Others (42 Customers)"],
        "FY23 Revenue (INR Cr)": [36.15, 24.10, 18.07, 12.05, 9.64, 7.23, 13.26],
        "FY24 Revenue (INR Cr)": [44.22, 27.64, 20.73, 13.82, 11.05, 8.29, 12.45],
        "FY25 Revenue (INR Cr)": [54.76, 29.60, 22.20, 14.80, 8.88, 4.44, 13.32],
        "Credit Terms (Days)": [90, 60, 45, 30, 30, 30, 30],
        "Status / Churn Risk": ["Active (Demanding 120-day terms)", "Active", "Active", "Active", "Declining Orders", "High Churn Risk (Disputed Invoices)", "Stable"]
    })
    cust_df.to_excel(writer, sheet_name="CustomerSales", index=False)

# 3. debtor_ageing.xlsx
with pd.ExcelWriter("sample_data/debtor_ageing.xlsx", engine="openpyxl") as writer:
    debtor_df = pd.DataFrame({
        "Customer Name": ["Apex Global Corp", "Zenith Logistics", "Nexus Retail Ltd", "Delta Tech", "Orion Enterprises", "Promoter Related Entity (Apex Allied)", "Small Debtors Pool"],
        "Total Outstanding (INR Cr)": [18.5, 7.2, 4.8, 3.5, 2.4, 3.2, 1.6],
        "0-30 Days": [6.2, 4.0, 3.0, 0.0, 0.8, 0.0, 1.2],
        "31-60 Days": [5.1, 2.2, 1.2, 0.5, 0.6, 0.0, 0.3],
        "61-90 Days": [4.0, 1.0, 0.6, 0.8, 0.5, 0.0, 0.1],
        "91-180 Days": [2.0, 0.0, 0.0, 1.0, 0.3, 1.2, 0.0],
        ">180 Days": [1.2, 0.0, 0.0, 1.2, 0.2, 2.0, 0.0],
        "Remarks": ["Overdue past credit limit", "Standard", "Standard", "Disputed invoice / Uncollectible risk", "Slow paying", "Related party overdue > 180 days", "Normal"]
    })
    debtor_df.to_excel(writer, sheet_name="DebtorAgeing", index=False)

# 4. creditor_ageing.xlsx
with pd.ExcelWriter("sample_data/creditor_ageing.xlsx", engine="openpyxl") as writer:
    creditor_df = pd.DataFrame({
        "Vendor Name": ["Polymer Supplies India", "Global Tech Components", "KMP Consulting Pvt Ltd", "Standard Freight Logistics", "Industrial Power Infra"],
        "Total Payable (INR Cr)": [9.5, 6.2, 3.8, 2.6, 2.0],
        "0-30 Days": [4.2, 3.0, 0.0, 1.8, 1.2],
        "31-60 Days": [3.1, 2.0, 0.0, 0.8, 0.6],
        "61-90 Days": [1.5, 1.2, 0.0, 0.0, 0.2],
        ">90 Days": [0.7, 0.0, 3.8, 0.0, 0.0],
        "Remarks": ["Normal credit", "Normal credit", "Related party fee payable holding > 90 days", "Normal", "Normal"]
    })
    creditor_df.to_excel(writer, sheet_name="CreditorAgeing", index=False)

# 5. vendor_data.xlsx
with pd.ExcelWriter("sample_data/vendor_data.xlsx", engine="openpyxl") as writer:
    vendor_df = pd.DataFrame({
        "Vendor Name": ["Polymer Supplies India", "Global Tech Components", "KMP Consulting Pvt Ltd", "Standard Freight Logistics", "Industrial Power Infra", "Others"],
        "FY25 Purchase (INR Cr)": [38.5, 24.2, 8.5, 5.2, 4.1, 2.0],
        "Category": ["Raw Materials", "Components", "Management Advisory", "Logistics", "Utilities", "General"],
        "Dependency / Risk": ["Sole Supplier (80% resin supply)", "Import dependency", "Related party (Promoter Director entity)", "Dual Sourced", "State Grid", "Low"]
    })
    vendor_df.to_excel(writer, sheet_name="VendorData", index=False)

# 6. gst_books.xlsx
with pd.ExcelWriter("sample_data/gst_books.xlsx", engine="openpyxl") as writer:
    gst_b_df = pd.DataFrame({
        "Period": ["Q1 FY25", "Q2 FY25", "Q3 FY25", "Q4 FY25", "Total FY25"],
        "Turnover in Books (INR Cr)": [35.0, 37.2, 38.8, 37.0, 148.0],
        "GST Liability Payable (INR Cr)": [6.30, 6.70, 6.98, 6.66, 26.64],
        "ITC Availed Books (INR Cr)": [4.20, 4.50, 4.65, 4.45, 17.80]
    })
    gst_b_df.to_excel(writer, sheet_name="GST_Books", index=False)

# 7. gst_return.xlsx
with pd.ExcelWriter("sample_data/gst_return.xlsx", engine="openpyxl") as writer:
    gst_r_df = pd.DataFrame({
        "Period": ["Q1 FY25", "Q2 FY25", "Q3 FY25", "Q4 FY25", "Total FY25"],
        "Turnover GSTR-3B (INR Cr)": [32.5, 37.2, 36.0, 35.5, 141.2],
        "GST Paid GSTR-3B (INR Cr)": [5.85, 6.70, 6.48, 6.39, 25.42],
        "ITC Auto-Populated GSTR-2A (INR Cr)": [3.60, 4.10, 4.15, 3.90, 15.75]
    })
    gst_r_df.to_excel(writer, sheet_name="GST_Returns", index=False)

# 8. tax_data.xlsx
with pd.ExcelWriter("sample_data/tax_data.xlsx", engine="openpyxl") as writer:
    tax_df = pd.DataFrame({
        "Assessment Year / Period": ["AY 2021-22", "AY 2022-23", "FY23-24 (GST)", "FY24-25 (TDS)"],
        "Tax Forum / Authority": ["Income Tax Appellate Tribunal (ITAT)", "CIT (Appeals)", "State GST Dept", "TDS Traces Department"],
        "Issue Description": [
            "Disallowance of Section 80IA deduction & transfer pricing adjustment on royalty",
            "Addition under Section 68 for unverified share premium",
            "Mismatch in GSTR-2A vs GSTR-3B ITC claims",
            "Short deduction of TDS under Section 194C & 194J"
        ],
        "Contingent Exposure (INR Cr)": [4.80, 2.50, 2.05, 0.45],
        "Management Assessment": ["Low likelihood", "Medium likelihood", "Medium likelihood", "Paid under protest"],
        "Source Citation": ["Tax_Assessment_Notice_AY22.pdf", "CIT_Appeals_Order.pdf", "GST_Audit_Notice.pdf", "TDS_Mismatch_Statement.xlsx"]
    })
    tax_df.to_excel(writer, sheet_name="TaxContingentLiabilities", index=False)

# 9. related_party_master.xlsx
with pd.ExcelWriter("sample_data/related_party_master.xlsx", engine="openpyxl") as writer:
    rp_master_df = pd.DataFrame({
        "Entity / Person Name": ["Rajesh Sharma", "Apex Allied Infra Pvt Ltd", "KMP Consulting Services", "Sunita Sharma", "Nexus Logistics LLP"],
        "Relationship": ["Promoter & Managing Director", "Promoter Control Entity (51% shareholding)", "Director Interested Entity", "Spouse of Director", "KMP Relative Enterprise"],
        "Common Director / PAN / Address": ["PAN: ABCPS1234F", "Common Director: Rajesh Sharma", "Registered address matches Target plant", "PAN: XYZPS5678K", "Common Director: Rajesh Sharma"],
        "FY25 Transaction Type": ["Remuneration & Perquisites", "Sale of Goods & Rent Paid", "Management Consultancy Fees", "Office Lease Rent", "Transport & Freight Charges"],
        "FY25 Value (INR Cr)": [4.20, 8.50, 3.80, 1.20, 2.60],
        "Arm's Length Evaluation": ["Exceeds benchmarking by 40%", "Rents 30% above market rates", "No formal contract / unverified services", "Lease agreement unrecorded in registrar", "Above market rates"]
    })
    rp_master_df.to_excel(writer, sheet_name="RelatedParties", index=False)

# 10. journal_entries.xlsx
with pd.ExcelWriter("sample_data/journal_entries.xlsx", engine="openpyxl") as writer:
    je_data = [
        ["2025-03-31", "JV-2025-901", "Unbilled Revenue A/c", "Revenue from Operations", 5500000.0, "SUPERADMIN", "Year-End Manual Closing Entry", "Unusual Timing / Round Number"],
        ["2025-03-31", "JV-2025-902", "Consultancy Expense A/c", "KMP Consulting Pvt Ltd", 3800000.0, "SUPERADMIN", "Year-End Advisory Fees", "Related Party / Post-Closing"],
        ["2025-03-29", "JV-2025-884", "Miscellaneous Expense", "Cash in Hand", 1000000.0, "FIN_USER_2", "Round Sum Settlement", "Round Number Entry"],
        ["2025-02-15", "JV-2025-412", "Trade Receivables - Apex", "Sales Account", 12500000.0, "ACCOUNTANT1", "Bulk Invoicing", "Large Value Entry"],
        ["2025-03-30", "JV-2025-899", "Promoter Drawings A/c", "Travel & Conveyance", 1200000.0, "SUPERADMIN", "Executive Travel Adjustment", "Owner Personal Expense"],
        ["2025-01-12", "JV-2025-210", "Raw Material Purchase", "Polymer Supplies India", 8542100.0, "PURCHASE_MGR", "Regular Procurement", "Normal"],
        ["2025-03-31", "JV-2025-905", "Inventory Write-back", "Cost of Goods Sold", 4500000.0, "SUPERADMIN", "Inventory Valuation Revision", "Post-Closing Reversal"],
        ["2025-03-28", "JV-2025-870", "Legal Expense A/c", "Bank Account", 2500000.0, "FIN_USER_1", "Out of court settlement", "Unusual Account / Large Round"],
    ]
    # Add 20 standard entries
    for i in range(1, 21):
        je_data.append([
            f"2025-02-{(i%28)+1:02d}", f"JV-2025-{100+i}", "Operating Expense", "Bank Account", round(12450.0 * i, 2), "ACCOUNTANT1", "Routine Operating Payment", "Normal"
        ])
    je_df = pd.DataFrame(je_data, columns=["Date", "Voucher No", "Debit Account", "Credit Account", "Amount (INR)", "Posted By", "Narration", "Exception Classification"])
    je_df.to_excel(writer, sheet_name="JournalEntries", index=False)

# 11. Demo_Legal_Memo.txt
memo_text = """CONFIDENTIAL M&A DUE DILIGENCE LEGAL MEMORANDUM
Target Company: Apex Industrial Solutions Ltd
Date: 15 March 2025
Prepared By: Strategic Advisory & Legal Counsel

1. LITIGATION & CONTINGENT LIABILITIES
- Pending Writ Petition before Hon'ble High Court regarding environmental compliance for Unit-2 plant at Tarapur. State Pollution Control Board has issued a show-cause notice demanding INR 3.50 Crore in environmental compensation.
- Disallowance of Section 80IA tax exemption amounting to INR 4.80 Crore pending before ITAT for AY 2021-22.

2. MATERIAL CONTRACTS & CUSTOMER CONCENTRATION
- Sales contract with top customer Apex Global Corp (contributing 37% of sales) is due for renewal on 31 December 2025. Customer has requested extension of credit terms from 90 days to 120 days.
- Sole supplier arrangement with Polymer Supplies India for key resin raw material contains no long-term price lock clause, exposing Target to raw material price inflation.

3. RELATED PARTY TRANSACTIONS & GOVERNANCE
- Management consultancy fee of INR 3.80 Crore paid annually to KMP Consulting Services (an entity 100% owned by the promoter's spouse) without formal contract or verifiable deliverables.
- Factory land at Unit-1 is leased from Sunita Sharma (spouse of Promoter Director) at an annual rent of INR 1.20 Crore, which is estimated to be 30% above prevailing commercial rates in the industrial zone.

4. EMPLOYEE & HR OBLIGATIONS
- Gratuity liability of INR 1.85 Crore is unfunded and recognized on pay-as-you-go basis rather than actuarial valuation under AS-15 / IND AS 19.
- Key Executive Non-Compete agreements are missing for 2 Senior Vice Presidents in charge of Product R&D.

[Source: Demo_Legal_Memo.txt | Page 1-3]
"""
with open("sample_data/Demo_Legal_Memo.txt", "w", encoding="utf-8") as f:
    f.write(memo_text)

print("Sample data successfully created in sample_data/")
