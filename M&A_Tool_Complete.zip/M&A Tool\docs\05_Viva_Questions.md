# ICAI AICA LEVEL-2 VIVA QUESTIONS & ANSWERS

### Q1: What is the primary objective of the M&A Copilot AI application?
**Answer**: To provide an AI-assisted decision-support platform for Chartered Accountants and M&A transaction teams to perform first-level due diligence, identify financial/QoE/tax risks, compute EV-to-Equity bridges, and generate management questions.

### Q2: How does the system ensure it does not hallucinate facts or financial numbers?
**Answer**: The RAG engine enforces a strict system prompt instruction: *"Use strictly supplied evidence wherever the question relates to the transaction. If evidence is insufficient, explicitly state: Insufficient evidence available in the Data Room."* Every response includes exact source citations `[Source: filename | Page/Sheet]`.

### Q3: Why does the app support an Offline Analytical Mode?
**Answer**: To ensure full functionality in confidential environment settings where real company data cannot be sent to external LLM APIs. The offline mode uses Scikit-Learn TF-IDF vectorization and cosine similarity retrieval combined with deterministic financial rule engines.

### Q4: How is Quality of Earnings (QoE) calculated?
**Answer**: It starts with Reported EBITDA, identifies one-time items, unverified promoter fees, non-business personal costs, and above-market rents, and applies them to calculate Adjusted (Normalised) EBITDA. All items are labeled as *"Potential adjustment — subject to validation"* to preserve CA professional judgment.

### Q5: What is the Working Capital Peg Analysis?
**Answer**: It compares the Target's Actual Net Working Capital ($CA - CL$) against a agreed normal baseline (Normalised Working Capital Peg). The difference ($WC_{actual} - WC_{peg}$) is deducted or added in the EV to Equity Value Bridge.

### Q6: How does the Forensic Journal Analytics engine work?
**Answer**: It analyzes the general ledger population for anomalies including round-number amounts, weekend/after-hours postings, manual post-closing JVs, privileged user accounts (SUPERADMIN), and unbilled revenue entries.

### Q7: What is the role of the Multi-Agent Architecture?
**Answer**: 9 domain-specialist AI agents (Financial, QoE, Tax, GST, Commercial, Related Party, Forensic, Legal, Valuation) analyze context in parallel. The M&A Lead Agent then synthesizes findings, removes duplicates, ranks risks, and compiles an executive summary.

### Q8: How does the app address professional liability and CA governance?
**Answer**: The application is explicitly designated as decision support. It embeds professional disclaimers on every page and report, includes a Human-in-the-Loop review trail where CAs accept or reject findings, and never replaces statutory audit or legal opinions.
