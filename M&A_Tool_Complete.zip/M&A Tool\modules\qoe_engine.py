"""
Quality of Earnings (QoE) Engine
Analyzes EBITDA quality, non-recurring items, promoter expenses, and potential normalization adjustments.
Follows professional CA guardrails: "Potential adjustment — subject to validation."
"""
import pandas as pd

def run_qoe_analysis():
    """
    Computes Reported EBITDA, Potential Adjustments, and Adjusted EBITDA.
    """
    reported_ebitda = 26.00  # FY25 Reported EBITDA (INR Cr)
    
    adjustments = [
        {
            "Item": "Non-Operating Other Income (Asset Sale Gain & Subsidies)",
            "Amount (INR Cr)": -4.20,
            "Potential Treatment": "Deduction from EBITDA",
            "Reason": "One-time gain from sale of surplus land & state industrial subsidy included in operational revenues.",
            "Evidence": "P&L Note 14 & Financial_Statements.pdf | Page 17",
            "Confidence": "High (95%)",
            "Management Confirmation": "Confirm non-recurrence of subsidy and exact gain on asset sale."
        },
        {
            "Item": "Unverified KMP Consultancy Advisory Fees",
            "Amount (INR Cr)": 3.80,
            "Potential Treatment": "Potential Add-back (Subject to Validation)",
            "Reason": "Fee paid to promoter-owned entity without formal contract or verifiable service scope.",
            "Evidence": "Related_Party_Master.xlsx & Journal_Entries.xlsx (Voucher JV-2025-902)",
            "Confidence": "Medium (75%)",
            "Management Confirmation": "Request timesheets, deliverables, and arm's length benchmarking study."
        },
        {
            "Item": "Promoter Personal & Non-Business Expenses",
            "Amount (INR Cr)": 1.20,
            "Potential Treatment": "Potential Add-back (Subject to Validation)",
            "Reason": "Personal executive travel, luxury vehicle maintenance, and domestic family expenses charged to administrative costs.",
            "Evidence": "Journal_Entries.xlsx (Voucher JV-2025-899)",
            "Confidence": "High (90%)",
            "Management Confirmation": "Verify expense log and promoter tax audit report notes."
        },
        {
            "Item": "Above-Market Factory Land Rent to Director Spouse",
            "Amount (INR Cr)": 0.40,
            "Potential Treatment": "Potential Add-back (Normalisation)",
            "Reason": "Rent paid is 30% above prevailing commercial rates in Tarapur industrial zone.",
            "Evidence": "Demo_Legal_Memo.txt | Section 3",
            "Confidence": "Medium (80%)",
            "Management Confirmation": "Independent property valuation / rental appraisal required."
        },
        {
            "Item": "Unfunded Gratuity & Actuarial Provision Shortfall",
            "Amount (INR Cr)": -0.85,
            "Potential Treatment": "Deduction from EBITDA / Debt-like Item",
            "Reason": "Gratuity accounted on pay-as-you-go basis; actuarial shortfall under AS-15 / IND AS 19.",
            "Evidence": "Demo_Legal_Memo.txt | Section 4",
            "Confidence": "High (90%)",
            "Management Confirmation": "Obtain actuarial valuation certificate as on transaction date."
        }
    ]
    
    adj_df = pd.DataFrame(adjustments)
    net_adjustment = adj_df["Amount (INR Cr)"].sum()
    adjusted_ebitda = reported_ebitda + net_adjustment
    
    summary = {
        "Reported EBITDA": reported_ebitda,
        "Net Potential Adjustments": round(net_adjustment, 2),
        "Adjusted EBITDA (Normalised)": round(adjusted_ebitda, 2),
        "EBITDA Haircut (%)": round(((reported_ebitda - adjusted_ebitda) / reported_ebitda) * 100, 1)
    }
    
    return adj_df, summary
