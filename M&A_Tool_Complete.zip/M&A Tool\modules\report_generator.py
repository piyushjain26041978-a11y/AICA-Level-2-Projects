"""
Report Generator Engine
Generates comprehensive multi-page M&A Due Diligence Reports in PDF (ReportLab),
Excel (14-sheet OpenPyXL workbook), and TXT formats.
"""
import os
import pandas as pd
from datetime import datetime

def generate_txt_report(target_name="Apex Industrial Solutions Ltd", acquirer_name="Strategic Investment Partners"):
    """
    Generates a detailed multi-section text report.
    """
    report = f"""================================================================================
M&A DUE DILIGENCE & DEAL INTELLIGENCE REPORT
Target Company: {target_name}
Acquirer Entity: {acquirer_name}
Evaluation Date: {datetime.now().strftime("%d %B %Y")}
Prepared By: M&A Copilot AI (Decision-Support Platform for Chartered Accountants)
================================================================================

1. EXECUTIVE SUMMARY & OVERALL DEAL RISK ASSESSMENT
--------------------------------------------------------------------------------
Overall Deal Risk Score: 72.8 / 100 (HIGH RISK)
Negotiated Base Enterprise Value (EV): INR 250.00 Cr
Indicative Equity Value: INR 194.48 Cr
Total Purchase Price Adjustment Haircut: -INR 55.52 Cr (-22.2% Haircut)

Key Deal-Breaker Findings:
1. EBITDA Quality Overstatement: Reported EBITDA of INR 26.0 Cr includes INR 9.05 Cr of non-operating asset sale gains, unverified advisory fees, and promoter personal expenses. Normalised EBITDA is INR 16.95 Cr.
2. Receivables & CFO Conversion Stress: Receivables DSO increased by +34 days to 102 days (INR 41.2 Cr); CFO/EBITDA conversion crashed from 73.3% to 30.0%.
3. Severe Customer Concentration: Top 1 customer (Apex Global Corp) contributes 37.0% of revenue (INR 54.76 Cr); sales contract expires on 31 December 2025.
4. Related Party Value Leakage: INR 16.10 Cr (10.9% of FY25 revenue) in related party transactions including unverified advisory fees (INR 3.80 Cr) and 30% above-market lease rents.
5. Indirect Tax Exposure: Turnover mismatch of INR 6.80 Cr between Books and GSTR-3B with unmatched GSTR-2A ITC claim of INR 2.05 Cr (Total tax exposure: INR 3.27 Cr).

2. FINANCIAL ANALYSIS & DUPONT ROE DECOMPOSITION
--------------------------------------------------------------------------------
- Revenue from Operations (FY25): INR 148.0 Cr (+7.1% YoY growth, down from +14.7% in FY24)
- Reported EBITDA (FY25): INR 26.0 Cr (17.6% margin, compressed by 270 bps)
- Net Debt (FY25): INR 32.0 Cr (Gross Debt: INR 36.5 Cr, Cash: INR 4.5 Cr | Net Debt/EBITDA: 1.23x)
- 3-Step DuPont ROE Breakdown:
  - FY23: Net Margin 10.87% x Asset Turnover 1.35x x Leverage 2.09x = ROE 30.82%
  - FY24: Net Margin 10.56% x Asset Turnover 1.32x x Leverage 2.05x = ROE 28.57%
  - FY25: Net Margin 8.24%  x Asset Turnover 1.15x x Leverage 2.20x = ROE 20.93%

3. QUALITY OF EARNINGS (QoE) EBITDA NORMALIZATION SCHEDULE
--------------------------------------------------------------------------------
Reported FY25 EBITDA: INR 26.00 Cr
- Deduct: Non-operating asset sale gain & industrial subsidy: -INR 4.20 Cr
+ Add: Unverified KMP Consultancy advisory fees: +INR 3.80 Cr (Subject to CA validation)
+ Add: Promoter personal & executive travel expenses: +INR 1.20 Cr (Subject to CA validation)
+ Add: Above-market factory land lease rent to spouse: +INR 0.40 Cr
- Deduct: Unfunded gratuity liability actuarial shortfall: -INR 0.85 Cr
--------------------------------------------------------------------------------
Normalised / Adjusted EBITDA: INR 16.95 Cr (Net EBITDA Haircut: -34.8%)

4. WORKING CAPITAL PEG ANALYSIS & OVERDUE AGEING
--------------------------------------------------------------------------------
- Actual FY25 Net Working Capital (NWC): INR 39.30 Cr
- Normalised Working Capital Peg Target: INR 28.50 Cr
- Working Capital Adjustment (Deduction): -INR 10.80 Cr
- Overdue Red Flags: INR 4.40 Cr in receivables overdue > 180 days (including INR 2.0 Cr related party balance); INR 3.80 Cr in raw material resin stock unutilized > 180 days.

5. INDIRECT TAX (GST 2A/3B) & DIRECT TAX DISPUTES
--------------------------------------------------------------------------------
- Total GSTR-3B Turnover Mismatch: INR 6.80 Cr (Undischarged tax shortfall: INR 1.22 Cr)
- Unmatched GSTR-2A Input Tax Credit Claim: INR 2.05 Cr
- Income Tax Contingent Liabilities: INR 7.75 Cr (Sec 80IA disallowance & Sec 68 share premium addition pending before ITAT and CIT Appeals).

6. COMMERCIAL CONCENTRATION & SUPPLIER DEPENDENCY
--------------------------------------------------------------------------------
- Top 1 Customer Share: 37.0% (Apex Global Corp - INR 54.76 Cr)
- Top 3 Customer Share: 72.0% (HHI Index: 2182 - Highly Concentrated)
- Top 1 Supplier Share: 46.7% (Polymer Supplies India - Sole resin supplier with no price lock)

7. FORENSIC JOURNAL ANALYTICS & BENFORD'S LAW FINDINGS
--------------------------------------------------------------------------------
- Exception Population: 8 manual entries flagged (INR 3.25 Cr total value)
- Key Anomaly: Voucher JV-2025-901 crediting unbilled revenue by INR 55.0 Lakhs posted by SUPERADMIN on 31 March 2025.
- Benford's Law Audit: Digit 1 frequency actual 38.2% vs Benford expected 30.1% (+8.1% variance spike).

8. DEAL VALUE BRIDGE & DYNAMIC SCENARIO LAB
--------------------------------------------------------------------------------
Base Negotiated Enterprise Value (EV): INR 250.00 Cr
Less: Net Debt: -INR 32.00 Cr
Less: Working Capital Peg Adjustment: -INR 10.80 Cr
Less: Unresolved Tax & GST Risk Exposure: -INR 8.07 Cr
Less: Debt-Like Obligations (Gratuity/Stock): -INR 4.65 Cr
--------------------------------------------------------------------------------
Indicative Equity Value: INR 194.48 Cr

Downside Scenario Impact (10% Sales Drop, 200 bps Margin Compression, +15% Customer Churn):
- Adjusted Enterprise Value: INR 208.50 Cr
- Adjusted Equity Value: INR 152.98 Cr (-21.3% Equity Value Erosion)

9. MULTI-METHOD VALUATION SUITE
--------------------------------------------------------------------------------
1. DCF FCFF Model (WACC 12.5%, g 3.0%): EV INR 196.20 Cr | Equity Value INR 140.68 Cr (40% Weight)
2. EV / Adjusted EBITDA (9.6x Multiple): EV INR 162.72 Cr | Equity Value INR 107.20 Cr (40% Weight)
3. EV / Revenue Multiple (1.5x Multiple): EV INR 222.00 Cr | Equity Value INR 166.48 Cr (10% Weight)
4. Adjusted Net Asset Value (NAV): EV INR 101.82 Cr | Equity Value INR 46.30 Cr (10% Weight)
--------------------------------------------------------------------------------
Weighted Average Enterprise Value: INR 188.75 Cr
Weighted Average Equity Value: INR 133.23 Cr (Indicative Fair Value: INR 133.23 / Share)

10. PRIORITY MANAGEMENT DUE DILIGENCE QUESTIONS
--------------------------------------------------------------------------------
1. [Financials] Please explain the reasons for the 44.1% increase in receivables relative to 7.1% sales growth, and provide subsequent collection data post 31 March 2025.
2. [QoE] Provide contracts, timesheets, and third-party arm's length benchmarking study for the INR 3.80 Cr advisory fee paid to promoter entity KMP Consulting.
3. [GST] Provide period-wise GSTR-3B vs GSTR-2A reconciliation for the INR 6.80 Cr turnover mismatch and INR 2.05 Cr unmatched ITC claim.
4. [Commercial] What is the status of contract renewal negotiations with top customer Apex Global Corp (37% sales share) expiring on 31 December 2025?

11. PROFESSIONAL GUARDRAILS & ICAI DISCLAIMER
--------------------------------------------------------------------------------
This report is generated by an AI-assisted decision-support system. All findings, EBITDA adjustments, 
working capital peg adjustments, and valuation multiples are indicative indicators requiring independent 
audit and legal validation by a practicing Chartered Accountant.
================================================================================
"""
    return report

def generate_excel_report(output_path="MA_Copilot_Due_Diligence_Report.xlsx"):
    """
    Generates a multi-tab Excel report containing 14 sheets.
    """
    with pd.ExcelWriter(output_path, engine="openpyxl") as writer:
        # Sheet 1: Summary
        sum_df = pd.DataFrame({
            "Parameter": ["Target Company", "Acquirer", "Evaluation Date", "Overall Risk Score", "Base EV", "Indicative Equity Value", "Weighted Fair Value / Share"],
            "Value": ["Apex Industrial Solutions Ltd", "Strategic Investment Partners", datetime.now().strftime("%Y-%m-%d"), "72.8 / 100 (HIGH RISK)", "INR 250.00 Cr", "INR 194.48 Cr", "INR 133.23 / share"]
        })
        sum_df.to_excel(writer, sheet_name="Summary", index=False)

        # Sheet 2: Financials
        from modules.financial_engine import run_financial_analysis
        fin_df = run_financial_analysis(None, None, None)
        fin_df.to_excel(writer, sheet_name="Financials", index=False)

        # Sheet 3: QoE
        from modules.qoe_engine import run_qoe_analysis
        qoe_df, _ = run_qoe_analysis()
        qoe_df.to_excel(writer, sheet_name="QoE", index=False)

        # Sheet 4: Working Capital
        from modules.working_capital_engine import run_working_capital_analysis
        _, wc_red_flags = run_working_capital_analysis()
        wc_red_flags.to_excel(writer, sheet_name="WorkingCapital", index=False)

        # Sheet 5: GST
        from modules.tax_gst_engine import run_gst_reconciliation
        gst_df, _ = run_gst_reconciliation()
        gst_df.to_excel(writer, sheet_name="GST", index=False)

        # Sheet 6: Tax
        from modules.tax_gst_engine import get_income_tax_summary
        tax_df = get_income_tax_summary()
        tax_df.to_excel(writer, sheet_name="Tax", index=False)

        # Sheet 7: Related Parties
        from modules.related_party_engine import run_related_party_analysis
        rp_df, _ = run_related_party_analysis()
        rp_df.to_excel(writer, sheet_name="RelatedParties", index=False)

        # Sheet 8: Forensic
        from modules.forensic_engine import run_forensic_journal_analytics
        forensic_df, _, _ = run_forensic_journal_analytics()
        forensic_df.to_excel(writer, sheet_name="Forensic", index=False)

        # Sheet 9: Customers
        from modules.commercial_engine import run_commercial_analysis
        cust_df, vendor_df, _ = run_commercial_analysis()
        cust_df.to_excel(writer, sheet_name="Customers", index=False)

        # Sheet 10: Vendors
        vendor_df.to_excel(writer, sheet_name="Vendors", index=False)

        # Sheet 11: Risk Register
        from modules.risk_scoring import calculate_overall_risk_score
        risk_df, _ = calculate_overall_risk_score()
        risk_df.to_excel(writer, sheet_name="RiskRegister", index=False)

        # Sheet 12: Deal Bridge
        from modules.deal_value_engine import build_deal_value_bridge
        bridge_df, _ = build_deal_value_bridge()
        bridge_df.to_excel(writer, sheet_name="DealBridge", index=False)

        # Sheet 13: Valuation Suite
        from modules.valuation_engine import run_multi_method_valuation_summary
        val_df, _ = run_multi_method_valuation_summary()
        val_df.to_excel(writer, sheet_name="ValuationSuite", index=False)

        # Sheet 14: Management Questions
        from modules.management_questions import generate_management_questions
        mq_df = generate_management_questions()
        mq_df.to_excel(writer, sheet_name="ManagementQuestions", index=False)
        
    return output_path

def generate_pdf_report(output_path="MA_Copilot_Due_Diligence_Report.pdf"):
    """
    Generates a detailed multi-page PDF report using ReportLab.
    """
    try:
        from reportlab.lib.pagesizes import letter
        from reportlab.lib import colors
        from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, PageBreak, HRFlowable
        from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle

        doc = SimpleDocTemplate(output_path, pagesize=letter, rightMargin=36, leftMargin=36, topMargin=36, bottomMargin=36)
        styles = getSampleStyleSheet()
        
        # Custom Typography & Colors
        title_style = ParagraphStyle(
            'TitleStyle',
            parent=styles['Heading1'],
            fontSize=20,
            leading=24,
            textColor=colors.HexColor('#1E3A8A'),
            spaceAfter=4
        )
        
        subtitle_style = ParagraphStyle(
            'SubTitleStyle',
            parent=styles['Normal'],
            fontSize=10,
            leading=14,
            textColor=colors.HexColor('#475569')
        )
        
        heading_style = ParagraphStyle(
            'HeadingStyle',
            parent=styles['Heading2'],
            fontSize=12,
            leading=16,
            textColor=colors.HexColor('#1E3A8A'),
            spaceBefore=10,
            spaceAfter=6
        )
        
        body_style = ParagraphStyle(
            'BodyStyle',
            parent=styles['Normal'],
            fontSize=9,
            leading=13,
            textColor=colors.HexColor('#0F172A')
        )
        
        bold_body_style = ParagraphStyle(
            'BoldBodyStyle',
            parent=styles['Normal'],
            fontSize=9,
            leading=13,
            fontName='Helvetica-Bold',
            textColor=colors.HexColor('#0F172A')
        )

        elements = []

        # Document Header
        elements.append(Paragraph("M&A COPILOT — COMPREHENSIVE DUE DILIGENCE REPORT", title_style))
        elements.append(Paragraph("<b>Target:</b> Apex Industrial Solutions Ltd | <b>Acquirer:</b> Strategic Investment Partners", subtitle_style))
        elements.append(Paragraph(f"<b>Evaluation Date:</b> {datetime.now().strftime('%d %B %Y')} | <b>Overall Risk Score:</b> 72.8 / 100 (HIGH RISK)", subtitle_style))
        elements.append(Spacer(1, 10))
        elements.append(HRFlowable(width="100%", thickness=1.5, color=colors.HexColor('#1E3A8A'), spaceAfter=12))

        # 1. Executive Summary
        elements.append(Paragraph("1. Executive Summary & Core Deal Intelligence", heading_style))
        exec_text = (
            "This M&A Due Diligence Report summarizes the comprehensive evaluation of Apex Industrial Solutions Ltd. "
            "The overall Deal Risk Score is <b>72.8 / 100 (HIGH RISK)</b>. Key transaction risks include <b>EBITDA Overstatement "
            "(INR 9.05 Cr adjustments)</b>, <b>Severe Receivables Bloat (+44% YoY, 102 DSO)</b>, <b>Customer Concentration "
            "(Top customer 37% revenue)</b>, and <b>Unverified Related-Party Leakage (INR 16.1 Cr volume)</b>."
        )
        elements.append(Paragraph(exec_text, body_style))
        elements.append(Spacer(1, 10))

        # 2. EV to Equity Value Bridge Table
        elements.append(Paragraph("2. Enterprise Value to Equity Value Bridge", heading_style))
        bridge_table_data = [
            [Paragraph("<b>Bridge Line Item</b>", bold_body_style), Paragraph("<b>Reported / Baseline</b>", bold_body_style), Paragraph("<b>Adjustment</b>", bold_body_style), Paragraph("<b>Indicative Figure</b>", bold_body_style)],
            ["Base Negotiated Enterprise Value (EV)", "INR 250.00 Cr", "-", "INR 250.00 Cr"],
            ["Less: Gross Debt", "INR 36.50 Cr", "-INR 36.50 Cr", "INR 213.50 Cr"],
            ["Add: Cash & Cash Equivalents", "INR 4.50 Cr", "+INR 4.50 Cr", "INR 218.00 Cr"],
            ["Less: Working Capital Peg Adjustment", "INR 39.30 Cr (Actual)", "-INR 10.80 Cr", "INR 207.20 Cr"],
            ["Less: Tax & GST Exposure", "-", "-INR 8.07 Cr", "INR 199.13 Cr"],
            ["Less: Debt-Like Obligations (Gratuity/Stock)", "-", "-INR 4.65 Cr", "INR 194.48 Cr"],
            [Paragraph("<b>INDICATIVE EQUITY VALUE</b>", bold_body_style), "INR 250.00 Cr", "-INR 55.52 Cr", Paragraph("<b>INR 194.48 Cr</b>", bold_body_style)]
        ]
        
        t_bridge = Table(bridge_table_data, colWidths=[180, 110, 110, 120])
        t_bridge.setStyle(TableStyle([
            ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor('#1E3A8A')),
            ('TEXTCOLOR', (0, 0), (-1, 0), colors.whitesmoke),
            ('BOTTOMPADDING', (0, 0), (-1, 0), 5),
            ('BACKGROUND', (0, -1), (-1, -1), colors.HexColor('#F1F5F9')),
            ('GRID', (0, 0), (-1, -1), 0.5, colors.HexColor('#CBD5E1')),
        ]))
        elements.append(t_bridge)
        elements.append(Spacer(1, 12))

        # 3. Quality of Earnings (QoE) Schedule
        elements.append(Paragraph("3. Quality of Earnings (QoE) Normalization Schedule", heading_style))
        qoe_table_data = [
            [Paragraph("<b>Adjustment Item</b>", bold_body_style), Paragraph("<b>Amount</b>", bold_body_style), Paragraph("<b>Potential Treatment</b>", bold_body_style)],
            ["Reported FY25 EBITDA", "INR 26.00 Cr", "Baseline EBITDA"],
            ["Non-Operating Asset Sale Gain & Subsidy", "-INR 4.20 Cr", "Deduction from EBITDA"],
            ["Unverified KMP Consultancy Advisory Fee", "+INR 3.80 Cr", "Potential Add-back (Subject to Validation)"],
            ["Promoter Personal & Non-Business Expenses", "+INR 1.20 Cr", "Potential Add-back (Subject to Validation)"],
            ["Above-Market Factory Rent to Spouse", "+INR 0.40 Cr", "Potential Add-back (Normalisation)"],
            ["Unfunded Gratuity Actuarial Shortfall", "-INR 0.85 Cr", "Deduction / Debt-like Item"],
            [Paragraph("<b>NORMALISED ADJUSTED EBITDA</b>", bold_body_style), Paragraph("<b>INR 16.95 Cr</b>", bold_body_style), Paragraph("<b>Net Haircut: -34.8%</b>", bold_body_style)]
        ]
        t_qoe = Table(qoe_table_data, colWidths=[200, 110, 210])
        t_qoe.setStyle(TableStyle([
            ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor('#0284C7')),
            ('TEXTCOLOR', (0, 0), (-1, 0), colors.whitesmoke),
            ('GRID', (0, 0), (-1, -1), 0.5, colors.HexColor('#CBD5E1')),
        ]))
        elements.append(t_qoe)
        elements.append(Spacer(1, 12))

        # 4. Multi-Method Valuation Matrix
        elements.append(Paragraph("4. Multi-Method Valuation Summary Matrix", heading_style))
        val_table_data = [
            [Paragraph("<b>Valuation Approach</b>", bold_body_style), Paragraph("<b>Methodology</b>", bold_body_style), Paragraph("<b>Enterprise Value</b>", bold_body_style), Paragraph("<b>Equity Value</b>", bold_body_style)],
            ["Income Approach", "Discounted Cash Flow (DCF)", "INR 196.20 Cr", "INR 140.68 Cr"],
            ["Market Approach", "EV / Adjusted EBITDA (9.6x)", "INR 162.72 Cr", "INR 107.20 Cr"],
            ["Market Approach", "EV / Revenue Multiple (1.5x)", "INR 222.00 Cr", "INR 166.48 Cr"],
            ["Asset Approach", "Adjusted Net Asset Value (NAV)", "INR 101.82 Cr", "INR 46.30 Cr"],
            [Paragraph("<b>WEIGHTED AVERAGE FAIR VALUE</b>", bold_body_style), "Combined Valuation", Paragraph("<b>INR 188.75 Cr</b>", bold_body_style), Paragraph("<b>INR 133.23 Cr</b>", bold_body_style)]
        ]
        t_val = Table(val_table_data, colWidths=[130, 170, 110, 110])
        t_val.setStyle(TableStyle([
            ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor('#0D9488')),
            ('TEXTCOLOR', (0, 0), (-1, 0), colors.whitesmoke),
            ('GRID', (0, 0), (-1, -1), 0.5, colors.HexColor('#CBD5E1')),
        ]))
        elements.append(t_val)
        elements.append(Spacer(1, 12))

        # 5. Top Priority Management Questions
        elements.append(Paragraph("5. Top Management Due Diligence Questions", heading_style))
        q1 = "<b>1. Financials & Cash Flow:</b> Please explain the commercial reasons for the 44.1% increase in receivables relative to 7.1% sales growth, and provide subsequent collection data post 31 March 2025."
        q2 = "<b>2. Quality of Earnings:</b> Provide copies of executed service agreement, board approvals, scope of work, and third-party benchmarking study for the INR 3.80 Cr consultancy fee paid to promoter-owned KMP Consulting."
        q3 = "<b>3. Indirect Tax:</b> Provide period-wise GSTR-3B vs GSTR-2A reconciliation for the INR 6.80 Cr turnover mismatch and INR 2.05 Cr unmatched ITC claim."
        q4 = "<b>4. Commercial Risk:</b> What is the status of contract renewal negotiations with top customer Apex Global Corp (37% sales share) whose contract expires on 31 December 2025?"

        elements.append(Paragraph(q1, body_style))
        elements.append(Spacer(1, 4))
        elements.append(Paragraph(q2, body_style))
        elements.append(Spacer(1, 4))
        elements.append(Paragraph(q3, body_style))
        elements.append(Spacer(1, 4))
        elements.append(Paragraph(q4, body_style))
        elements.append(Spacer(1, 12))

        # 6. Professional Guardrails & Disclaimer
        elements.append(Paragraph("6. Professional Guardrails & ICAI Ethical Disclaimer", heading_style))
        disc_text = (
            "<i>DISCLAIMER: This report is generated by M&A Copilot AI, an AI-assisted professional decision-support system "
            "designed for Chartered Accountants and M&A transaction teams. All findings, EBITDA adjustments, working capital "
            "peg adjustments, tax exposures, and valuation matrices are indicative indicators requiring independent audit "
            "and legal validation by a practicing Chartered Accountant. This report is NOT a valuation opinion under Sec 247 "
            "of the Companies Act 2013 or IBBI guidelines.</i>"
        )
        elements.append(Paragraph(disc_text, body_style))

        doc.build(elements)
        return output_path
    except Exception as e:
        with open(output_path + ".txt", "w", encoding="utf-8") as f:
            f.write(generate_txt_report())
        return output_path + ".txt"
