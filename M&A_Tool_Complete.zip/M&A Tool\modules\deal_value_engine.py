"""
Deal Value Engine
Computes Enterprise Value (EV) to Equity Value Bridge.
Distinguishes between Reported, Calculated, Illustrative, and AI-estimated figures.
Follows CA Guardrail: "Never represent the output as a valuation opinion."
"""
import pandas as pd

def build_deal_value_bridge(base_ev=250.0, gross_debt=36.5, cash=4.5, wc_adj=10.8, tax_exp=8.07, debt_like=4.65, qoe_adj=0.0):
    """
    Computes EV to Equity Value Bridge.
    Base EV: INR Cr (Default: 250.0 Cr based on ~9.6x Adjusted EBITDA)
    """
    net_debt = gross_debt - cash
    
    bridge = [
        {"Line Item": "Enterprise Value (EV)", "Amount (INR Cr)": base_ev, "Classification": "Reported / Negotiated Base EV"},
        {"Line Item": "Less: Gross Interest-Bearing Debt", "Amount (INR Cr)": -gross_debt, "Classification": "Calculated Balance Sheet Debt"},
        {"Line Item": "Add: Cash & Cash Equivalents", "Amount (INR Cr)": cash, "Classification": "Calculated Balance Sheet Cash"},
        {"Line Item": "Net Debt Adjustment", "Amount (INR Cr)": -net_debt, "Classification": "Calculated Net Debt"},
        {"Line Item": "Less / Add: Working Capital Adjustment (NWC vs Peg)", "Amount (INR Cr)": -wc_adj if wc_adj > 0 else abs(wc_adj), "Classification": "Calculated NWC Shortfall / Peg Adj"},
        {"Line Item": "Less: Unresolved Tax & GST Risk Exposure", "Amount (INR Cr)": -tax_exp, "Classification": "AI-estimated Contingent Exposure"},
        {"Line Item": "Less: Debt-Like Items (Unfunded Gratuity + Obsolete Stock)", "Amount (INR Cr)": -debt_like, "Classification": "Identified Debt-like Obligation"},
        {"Line Item": "Less: Other QoE EBITDA Multiple Haircut Impact", "Amount (INR Cr)": -qoe_adj, "Classification": "Illustrative QoE Impact"}
    ]
    
    bridge_df = pd.DataFrame(bridge)
    
    # Equity Value calculation
    indicative_equity_value = base_ev - net_debt - (wc_adj if wc_adj > 0 else abs(wc_adj)) - tax_exp - debt_like - qoe_adj
    
    summary = {
        "Base Enterprise Value (EV)": base_ev,
        "Net Debt": net_debt,
        "Working Capital Adjustment": wc_adj,
        "Tax Exposure Deduction": tax_exp,
        "Debt-like Obligations": debt_like,
        "Indicative Equity Value": round(indicative_equity_value, 2),
        "EV to Equity Value Haircut (%)": round(((base_ev - indicative_equity_value) / base_ev) * 100, 1)
    }
    
    return bridge_df, summary
